# RPC ABI

Public C headers are under `include/heraix/`: `abi.h`, `api.h`, `system.h`, `memory.h`, `resource.h`, `device.h`, `storage.h`, `fs.h` and `file.h`. `include/heraix_rpc.h` contains the current service IDs, opcodes and shared-memory addresses used by the implementation.

## Request/Response

`heraix_rpc_t` is 88 bytes in ABI version 1:

| Field | Type | Meaning |
| --- | --- | --- |
| `service`, `opcode`, `seq` | `uint32_t` | Target service, operation and nonzero transaction sequence |
| `status` | `int32_t` | `0` on success; negative Heraix status otherwise |
| `version`, `size` | `uint16_t` | ABI version (`1`) and exact structure size (`88`) |
| `flags` | `uint32_t` | Must currently be zero |
| `arg0..arg2` | `uint64_t` | Operation inputs |
| `value0..value3` | `uint64_t` | Operation outputs |
| `used_blocks`, `reserved` | `uint32_t` | Allocator result and reserved extension field |

Every implemented service rejects a service mismatch, zero sequence, unsupported version, incorrect size, nonzero flags and unknown opcode where its handler has an opcode dispatch. Callers must not treat a notification as success until the response sequence, service and status have been checked.

Status values: `RPC_OK=0`, `RPC_BAD_REQUEST=-1`, `RPC_NO_MEMORY=-2`, `RPC_NOT_FOUND=-3`, `RPC_INVALID_RANGE=-4`, `RPC_INVALID_HANDLE=-5`, `RPC_PERMISSION=-6`, `RPC_ALREADY_EXISTS=-7`.

## Service IDs and Operations

| Service ID | Service | Implemented operation IDs |
| ---: | --- | --- |
| 1 | System | `GET_INFO=1` |
| 2 | Memory | `ALLOC=1` |
| 3 | Resource | `GET_RESOURCE=1` |
| 4 | Device | `DEVICE_LOOKUP=1` |
| 5 | Storage | `STORAGE_INFO=1`, `BLOCK_READ=2`, `BLOCK_WRITE=3` |
| 6 | VFS | `OPEN=1`, `CLOSE=2`, `READ=3`, `WRITE=4`, `SEEK=5`, `STAT=6`, `READDIR=7`, `MKDIR=8`, `CREATE=9`, `UNLINK=10`, `RENAME=11` |
| 7 | File | Same operation numbering for the File Service interface |
| 8 | Userland | `EXEC=1` |
| 9 | Process | `CREATE=1`, `EXIT=2`, `QUERY=3`, `THREAD_CREATE=4`, `THREAD_EXIT=5` |
| 10 | Security | `USER_CREATE=1`, `GROUP_CREATE=2`, `GROUP_ADD_MEMBER=3`, `TOKEN_ISSUE=4`, `TOKEN_REVOKE=5`, `ACL_SET=6`, `ACL_CHECK=7` |

Storage block requests use `arg0=block index`, `arg1=byte count`, `arg2=offset within block`. The transfer bytes start at `storage_io`. VFS/File path strings start at `vfs_io` offset 0; file contents start at offset 256. File Service descriptors and VFS handles encode a slot in the low byte and a generation in higher bits; callers must preserve the full 64-bit handle.

System `OP_GET_HEALTH` returns the healthy statically composed service count in `value0` and aggregate state (`1=healthy`) in `value1`. Memory `OP_FREE` uses `arg0=pool byte offset`, `arg1=1`; only allocated, block-aligned offsets are accepted and the response reports the remaining allocation count in `used_blocks`.

Process Service uses `arg0=parent PID`, `arg1=owner UID` for `CREATE`; `arg0=PID` for `EXIT`/`QUERY`/`THREAD_CREATE`; and `arg0=TID` for `THREAD_EXIT`/`THREAD_QUERY`. Process Query returns state/thread count/parent/owner in `value0..value3`, resource blocks in `used_blocks`, security token in `reserved`, and service permissions in `arg2`; Thread Query returns state/parent PID in `value0..value1` and resource blocks in `used_blocks`. Security Service uses numeric user/group IDs and generation-independent token IDs; `ACL_SET` uses `arg0=object`, `arg1=UID`, `arg2=rights`, while `ACL_CHECK` uses `arg0=token`, `arg1=object`, `arg2=requested rights`. Root UID/token are 0/1. Rights are read `0x1`, write `0x2`, execute `0x4`.

RPC `reserved` carries the caller Security Token across Application → File → VFS. `reserved==0` is compatibility-mapped to root token 1 at the VFS authorization gate; callers may set an explicit token with `heraix_rpc_set_token()`.

## Evolution

Version 1 requires exact-size requests and zero flags. Incompatible layouts require a new version. New fields/opcodes must define their validation and error behavior before use; reserved fields are not currently interpreted. Public inline helpers build requests but do not send Microkit notifications: the caller uses the channel assigned by the system description.
