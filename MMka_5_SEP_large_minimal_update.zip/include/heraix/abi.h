#ifndef HERAIX_ABI_H
#define HERAIX_ABI_H

#include <stdint.h>

#define HERAIX_ABI_VERSION 1U
#define HERAIX_ABI_FLAGS_NONE 0U

#define RPC_OK                 0
#define RPC_BAD_REQUEST       -1
#define RPC_NO_MEMORY         -2
#define RPC_NOT_FOUND         -3
#define RPC_INVALID_RANGE     -4
#define RPC_INVALID_HANDLE    -5
#define RPC_PERMISSION        -6
#define RPC_ALREADY_EXISTS    -7

typedef struct {
    uint32_t service;
    uint32_t opcode;
    uint32_t seq;
    int32_t status;
    uint16_t version;
    uint16_t size;
    uint32_t flags;
    uint64_t arg0;
    uint64_t arg1;
    uint64_t arg2;
    uint64_t value0;
    uint64_t value1;
    uint64_t value2;
    uint64_t value3;
    uint32_t used_blocks;
    uint32_t reserved;
} heraix_rpc_t;

_Static_assert(sizeof(heraix_rpc_t) <= 4096, "RPC too large");

#endif