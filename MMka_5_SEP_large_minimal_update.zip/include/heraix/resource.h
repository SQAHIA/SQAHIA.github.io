#ifndef HERAIX_RESOURCE_H
#define HERAIX_RESOURCE_H

#include "api.h"

static inline int32_t heraix_resource_get_info(volatile heraix_rpc_t *rpc,
                                                uint32_t sequence)
{
    return heraix_rpc_prepare(rpc, sequence, SVC_RESOURCE,
                              OP_GET_RESOURCE, 1, 0, 0);
}

#endif