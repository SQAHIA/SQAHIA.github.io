#ifndef HERAIX_STORAGE_H
#define HERAIX_STORAGE_H

#include "api.h"

static inline int32_t heraix_storage_info(volatile heraix_rpc_t *rpc,
                                           uint32_t sequence)
{
    return heraix_rpc_prepare(rpc, sequence, SVC_STORAGE,
                              OP_STORAGE_INFO, 0, 0, 0);
}

static inline int32_t heraix_storage_read(volatile heraix_rpc_t *rpc,
                                           uint32_t sequence,
                                           uint64_t block,
                                           uint64_t length,
                                           uint64_t offset)
{
    return heraix_rpc_prepare(rpc, sequence, SVC_STORAGE, OP_BLOCK_READ,
                              block, length, offset);
}

static inline int32_t heraix_storage_write(volatile heraix_rpc_t *rpc,
                                            uint32_t sequence,
                                            uint64_t block,
                                            uint64_t length,
                                            uint64_t offset)
{
    return heraix_rpc_prepare(rpc, sequence, SVC_STORAGE, OP_BLOCK_WRITE,
                              block, length, offset);
}

#endif