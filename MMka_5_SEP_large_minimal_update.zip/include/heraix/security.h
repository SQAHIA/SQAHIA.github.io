#ifndef HERAIX_SECURITY_H
#define HERAIX_SECURITY_H

#include "heraix/api.h"

#define HERAIX_RIGHT_READ  0x1U
#define HERAIX_RIGHT_WRITE 0x2U
#define HERAIX_RIGHT_EXEC  0x4U
#define HERAIX_TOKEN_ROOT  1U
#define HERAIX_VFS_OBJECT  0x1000ULL

static inline int32_t heraix_security_request(volatile heraix_rpc_t *rpc,
                                               uint32_t sequence,
                                               uint32_t opcode,
                                               uint64_t arg0,
                                               uint64_t arg1,
                                               uint64_t arg2)
{
    return heraix_rpc_prepare(rpc, sequence, SVC_SECURITY, opcode,
                               arg0, arg1, arg2);
}

#endif
