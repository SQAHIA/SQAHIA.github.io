#ifndef HERAIX_DEVICE_H
#define HERAIX_DEVICE_H

#include "api.h"

static inline int32_t heraix_device_lookup(volatile heraix_rpc_t *rpc,
                                            uint32_t sequence,
                                            uint16_t vendor,
                                            uint16_t product)
{
    return heraix_rpc_prepare(rpc, sequence, SVC_DEVICE, OP_DEVICE_LOOKUP,
                              vendor, product, 0);
}

#endif