#ifndef HERAIX_API_H
#define HERAIX_API_H

#include "heraix_rpc.h"

static inline int32_t heraix_rpc_prepare(volatile heraix_rpc_t *rpc,
                                         uint32_t sequence,
                                         uint32_t service,
                                         uint32_t opcode,
                                         uint64_t arg0,
                                         uint64_t arg1,
                                         uint64_t arg2)
{
    if (rpc == 0 || sequence == 0 || service == 0 || opcode == 0) {
        return RPC_BAD_REQUEST;
    }
    rpc->service = service;
    rpc->opcode = opcode;
    rpc->seq = sequence;
    rpc->status = 0;
    rpc->version = HERAIX_ABI_VERSION;
    rpc->size = (uint16_t)sizeof(heraix_rpc_t);
    rpc->flags = HERAIX_ABI_FLAGS_NONE;
    rpc->arg0 = arg0;
    rpc->arg1 = arg1;
    rpc->arg2 = arg2;
    rpc->value0 = 0;
    rpc->value1 = 0;
    rpc->value2 = 0;
    rpc->value3 = 0;
    return RPC_OK;
}

static inline int heraix_rpc_valid_request(const volatile heraix_rpc_t *rpc,
                                            uint32_t service)
{
    return rpc != 0 && rpc->service == service && rpc->seq != 0 &&
           rpc->version == HERAIX_ABI_VERSION &&
           rpc->size == sizeof(heraix_rpc_t) &&
           rpc->flags == HERAIX_ABI_FLAGS_NONE;
}

static inline int32_t heraix_rpc_set_token(volatile heraix_rpc_t *rpc,
                                           uint32_t token)
{
    if (rpc == 0 || token == 0) {
        return RPC_BAD_REQUEST;
    }
    rpc->reserved = token;
    return RPC_OK;
}

static inline int32_t heraix_path_store(volatile uint8_t *buffer,
                                        uint32_t capacity,
                                        const char *path)
{
    if (buffer == 0 || path == 0 || capacity == 0) {
        return RPC_BAD_REQUEST;
    }
    uint32_t index = 0;
    while (path[index] != '\0') {
        if (index + 1 >= capacity) {
            return RPC_INVALID_RANGE;
        }
        buffer[index] = (uint8_t)path[index];
        ++index;
    }
    buffer[index] = 0;
    return RPC_OK;
}

#endif
