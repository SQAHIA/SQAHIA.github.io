#ifndef HERAIX_MEMORY_H
#define HERAIX_MEMORY_H

#include "api.h"

static inline int32_t heraix_memory_alloc(volatile heraix_rpc_t *rpc,
                                           uint32_t sequence)
{
    return heraix_rpc_prepare(rpc, sequence, SVC_MEMORY, OP_ALLOC, 1, 0, 0);
}

static inline int32_t heraix_memory_free(volatile heraix_rpc_t *rpc,
                                          uint32_t sequence, uint64_t offset)
{
    return heraix_rpc_prepare(rpc, sequence, SVC_MEMORY, OP_FREE, offset, 1, 0);
}

#endif
