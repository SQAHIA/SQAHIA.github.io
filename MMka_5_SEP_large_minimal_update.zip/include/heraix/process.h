#ifndef HERAIX_PROCESS_H
#define HERAIX_PROCESS_H

#include "heraix/api.h"

/* A name occupies one RPC uint64_t, including its NUL terminator. */
#define HERAIX_PROCESS_NAME_MAX 8U
#define HERAIX_PROCESS_STATE_RUNNING 1U

#define HERAIX_PROCESS_EVENT_CREATED      1U
#define HERAIX_PROCESS_EVENT_THREAD_CREATE 2U
#define HERAIX_PROCESS_EVENT_THREAD_EXIT  3U
#define HERAIX_PROCESS_EVENT_EXIT         4U

static inline int32_t heraix_process_name_pack(const char *name,
                                                uint64_t *packed)
{
    if (name == 0 || packed == 0) {
        return RPC_BAD_REQUEST;
    }
    *packed = 0;
    for (uint32_t i = 0; i < HERAIX_PROCESS_NAME_MAX; ++i) {
        uint8_t character = (uint8_t)name[i];
        *packed |= ((uint64_t)character) << (i * 8U);
        if (character == 0) {
            return RPC_OK;
        }
    }
    return RPC_INVALID_RANGE;
}

static inline int32_t heraix_process_request(volatile heraix_rpc_t *rpc,
                                              uint32_t sequence,
                                              uint32_t opcode,
                                              uint64_t arg0,
                                              uint64_t arg1)
{
    return heraix_rpc_prepare(rpc, sequence, SVC_PROCESS, opcode,
                               arg0, arg1, 0);
}

/* CREATE carries parent PID, owner UID, and the packed name in arg0..arg2. */
static inline int32_t heraix_process_create_named(volatile heraix_rpc_t *rpc,
                                                   uint32_t sequence,
                                                   uint32_t parent_pid,
                                                   uint32_t owner_uid,
                                                   const char *name)
{
    uint64_t packed_name;
    int32_t status = heraix_process_name_pack(name, &packed_name);
    if (status != RPC_OK) {
        return status;
    }
    return heraix_rpc_prepare(rpc, sequence, SVC_PROCESS, OP_PROCESS_CREATE,
                               parent_pid, owner_uid, packed_name);
}

/* Enumeration input is a bounded table cursor; arg2 returns the packed name. */
static inline int32_t heraix_process_enumerate(volatile heraix_rpc_t *rpc,
                                                uint32_t sequence,
                                                uint32_t cursor)
{
    return heraix_rpc_prepare(rpc, sequence, SVC_PROCESS,
                               OP_PROCESS_ENUMERATE, cursor, 0, 0);
}

/* Event query returns the first retained event with sequence greater than arg0. */
static inline int32_t heraix_process_event_query(volatile heraix_rpc_t *rpc,
                                                  uint32_t sequence,
                                                  uint32_t after_sequence)
{
    return heraix_rpc_prepare(rpc, sequence, SVC_PROCESS,
                               OP_PROCESS_EVENT_QUERY, after_sequence, 0, 0);
}

#endif
