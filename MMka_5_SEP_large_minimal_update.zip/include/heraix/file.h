#ifndef HERAIX_FILE_H
#define HERAIX_FILE_H

#include "api.h"

static inline int32_t heraix_file_open(volatile heraix_rpc_t *rpc,
                                       volatile uint8_t *io,
                                       uint32_t sequence,
                                       const char *path,
                                       uint32_t flags)
{
    int32_t status = heraix_path_store(io, HERAIX_VFS_DATA_OFFSET, path);
    if (status != RPC_OK) {
        return status;
    }
    return heraix_rpc_prepare(rpc, sequence, SVC_FILE, OP_FILE_OPEN,
                              flags, 0, 0);
}

static inline int32_t heraix_file_handle_request(volatile heraix_rpc_t *rpc,
                                                  uint32_t sequence,
                                                  uint32_t opcode,
                                                  uint64_t descriptor,
                                                  uint64_t argument)
{
    return heraix_rpc_prepare(rpc, sequence, SVC_FILE, opcode,
                              descriptor, argument, 0);
}

static inline int32_t heraix_file_path_request(volatile heraix_rpc_t *rpc,
                                                volatile uint8_t *io,
                                                uint32_t sequence,
                                                uint32_t opcode,
                                                const char *path)
{
    int32_t status = heraix_path_store(io, HERAIX_VFS_DATA_OFFSET, path);
    if (status != RPC_OK) {
        return status;
    }
    return heraix_rpc_prepare(rpc, sequence, SVC_FILE, opcode, 0, 0, 0);
}

static inline int32_t heraix_file_mkdir(volatile heraix_rpc_t *rpc,
                                         volatile uint8_t *io,
                                         uint32_t sequence,
                                         const char *path)
{
    return heraix_file_path_request(rpc, io, sequence, OP_FILE_MKDIR, path);
}

#endif