#ifndef HERAIX_FS_H
#define HERAIX_FS_H

#include "api.h"

static inline int32_t heraix_fs_path_request(volatile heraix_rpc_t *rpc,
                                              uint32_t sequence,
                                              uint32_t opcode)
{
    return heraix_rpc_prepare(rpc, sequence, SVC_VFS, opcode, 0, 0, 0);
}

#endif