#ifndef HERAIX_SYSTEM_H
#define HERAIX_SYSTEM_H

#include "api.h"

static inline int32_t heraix_system_get_info(volatile heraix_rpc_t *rpc,
                                              uint32_t sequence)
{
    return heraix_rpc_prepare(rpc, sequence, SVC_SYSTEM, OP_GET_INFO, 1, 0, 0);
}

static inline int32_t heraix_system_get_health(volatile heraix_rpc_t *rpc,
                                                uint32_t sequence)
{
    return heraix_rpc_prepare(rpc, sequence, SVC_SYSTEM, OP_GET_HEALTH, 1, 0, 0);
}

#endif
