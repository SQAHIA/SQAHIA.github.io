/*-
 * SPDX-License-Identifier: BSD-3-Clause
 *
 * Copyright (c) 1991, 1993
 * The Regents of the University of California. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the University nor the names of its contributors may
 *    be used to endorse or promote products derived from this software without
 *    specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS "AS IS" AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Adapted from FreeBSD sys/sys/queue.h. Only the STAILQ operations needed by
 * the Heraix RAMFS registry are included; debug hooks and unrelated queue
 * variants are omitted. Pointer representation and queue behavior are retained.
 */

#ifndef HERAIX_COMPAT_FREEBSD_STAILQ_H
#define HERAIX_COMPAT_FREEBSD_STAILQ_H

#define STAILQ_HEAD(name, type) \
struct name { \
    struct type *stqh_first; \
    struct type **stqh_last; \
}

#define STAILQ_ENTRY(type) \
struct { \
    struct type *stqe_next; \
}

#define STAILQ_FIRST(head) ((head)->stqh_first)
#define STAILQ_NEXT(element, field) ((element)->field.stqe_next)
#define STAILQ_EMPTY(head) (STAILQ_FIRST(head) == 0)

#define STAILQ_INIT(head) do { \
    STAILQ_FIRST(head) = 0; \
    (head)->stqh_last = &STAILQ_FIRST(head); \
} while (0)

#define STAILQ_FOREACH(variable, head, field) \
    for ((variable) = STAILQ_FIRST(head); (variable) != 0; \
         (variable) = STAILQ_NEXT(variable, field))

#define STAILQ_INSERT_TAIL(head, element, field) do { \
    STAILQ_NEXT(element, field) = 0; \
    *(head)->stqh_last = (element); \
    (head)->stqh_last = &STAILQ_NEXT(element, field); \
} while (0)

#define STAILQ_REMOVE_HEAD(head, field) do { \
    if ((STAILQ_FIRST(head) = STAILQ_NEXT(STAILQ_FIRST(head), field)) == 0) \
        (head)->stqh_last = &STAILQ_FIRST(head); \
} while (0)

#define STAILQ_REMOVE(head, element, type, field) do { \
    if (STAILQ_FIRST(head) == (element)) { \
        STAILQ_REMOVE_HEAD(head, field); \
    } else { \
        struct type *_heraix_previous = STAILQ_FIRST(head); \
        while (STAILQ_NEXT(_heraix_previous, field) != (element)) \
            _heraix_previous = STAILQ_NEXT(_heraix_previous, field); \
        if ((STAILQ_NEXT(_heraix_previous, field) = \
             STAILQ_NEXT(element, field)) == 0) \
            (head)->stqh_last = &STAILQ_NEXT(_heraix_previous, field); \
    } \
} while (0)

#endif