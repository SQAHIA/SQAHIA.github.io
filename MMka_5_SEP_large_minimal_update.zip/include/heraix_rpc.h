#ifndef HERAIX_RPC_H
#define HERAIX_RPC_H
#include "heraix/abi.h"

#define HERAIX_RPC_VADDR       0x30000000UL
#define HERAIX_POOL_VADDR      0x31000000UL
#define HERAIX_POOL_SIZE       0x10000UL
#define HERAIX_BLOCK_SIZE     0x1000UL
#define HERAIX_BLOCK_COUNT     16U
#define HERAIX_STORAGE_IO_VADDR 0x32000000UL
#define HERAIX_VFS_IO_VADDR    0x33000000UL
#define HERAIX_VFS_PATH_OFFSET 0U
#define HERAIX_VFS_DATA_OFFSET 256U
#define HERAIX_USERLAND_IO_VADDR 0x34000000UL
#define HERAIX_USERLAND_OUTPUT_OFFSET 512U

#define SVC_SYSTEM             1U
#define SVC_MEMORY             2U
#define SVC_RESOURCE           3U
#define SVC_DEVICE             4U
#define SVC_STORAGE            5U
#define SVC_VFS                6U
#define SVC_FILE               7U
#define SVC_USERLAND           8U
#define SVC_PROCESS            9U
#define SVC_SECURITY           10U

#define OP_GET_INFO            1U
#define OP_GET_HEALTH          2U
#define OP_ALLOC               1U
#define OP_FREE                2U
#define OP_GET_RESOURCE        1U
#define OP_DEVICE_LOOKUP       1U
#define OP_STORAGE_INFO        1U
#define OP_BLOCK_READ          2U
#define OP_BLOCK_WRITE         3U
#define OP_VFS_OPEN            1U
#define OP_VFS_CLOSE           2U
#define OP_VFS_READ            3U
#define OP_VFS_WRITE           4U
#define OP_VFS_SEEK            5U
#define OP_VFS_STAT            6U
#define OP_VFS_READDIR         7U
#define OP_VFS_MKDIR           8U
#define OP_VFS_CREATE          9U
#define OP_VFS_UNLINK          10U
#define OP_VFS_RENAME          11U
#define OP_FILE_OPEN           1U
#define OP_FILE_CLOSE          2U
#define OP_FILE_READ           3U
#define OP_FILE_WRITE          4U
#define OP_FILE_SEEK           5U
#define OP_FILE_STAT           6U
#define OP_FILE_READDIR        7U
#define OP_FILE_CREATE         8U
#define OP_FILE_UNLINK         9U
#define OP_FILE_RENAME         10U
#define OP_FILE_MKDIR          11U
#define OP_USERLAND_EXEC       1U
#define OP_PROCESS_CREATE      1U
#define OP_PROCESS_EXIT        2U
#define OP_PROCESS_QUERY       3U
#define OP_THREAD_CREATE       4U
#define OP_THREAD_EXIT         5U
#define OP_THREAD_QUERY        6U
#define OP_PROCESS_ENUMERATE   7U
#define OP_PROCESS_EVENT_QUERY 8U
#define OP_USER_CREATE         1U
#define OP_GROUP_CREATE        2U
#define OP_GROUP_ADD_MEMBER    3U
#define OP_TOKEN_ISSUE         4U
#define OP_TOKEN_REVOKE        5U
#define OP_ACL_SET             6U
#define OP_ACL_CHECK           7U

#define HERAIX_DEVICE_OWNER_DEVICE_SERVICE 1U
#define HERAIX_STORAGE_OWNER_STORAGE_SERVICE 1U

#endif
