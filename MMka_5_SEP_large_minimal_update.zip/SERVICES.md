# Services

All listed protection domains are statically composed by `configs/x86_64/core.system` and built by `scripts/mmka.py`. Root and service control messages share the versioned RPC page; filesystem and block payloads use separately mapped shared regions.

| Service | Current behavior | Important limit |
| --- | --- | --- |
| Root | Boot test client; chains real RPC calls and checks response data/status. | Not a general-purpose init supervisor. |
| System | Returns system information and aggregate health (`healthy service count`, state) through RPC. | No configuration/policy database yet. |
| Memory | Allocates and safely frees one of 16 fixed 4 KiB pool blocks; rejects unaligned, out-of-range and double-free requests. | No paging policy, dynamic region creation or protection-domain mapping. |
| Resource | Reports the current pool/block resource description. | No general resource accounting or lease API. |
| Device | Scans PCI bus 0, records vendor/product/class/BDF, and verifies live PCI config identity on lookup. | Only PCI config I/O; no BAR sizing, MMIO mapping, IRQ registration, ownership transfer or bus enumeration. |
| Storage | RAM-backed 16-block device, 4 KiB/block; info, offset read/write and bounds errors. | Volatile data; no physical block device or persistence. |
| VFS | Root and `/system` namespace, plus `/system/boot` backed by Storage block 0. Implements open/close/read/write/seek/stat/readdir and mounts `/tmp` RAMFS. | The Storage-backed namespace is a single fixed file, not an on-disk filesystem. |
| RAMFS | `/tmp` directory tree with bounded node pool, directories/files, create, mkdir, read/write, stat, readdir, rename and unlink. | 16 nodes maximum, files capped at 4 KiB, all data volatile; no permissions, links, timestamps or concurrent operations. |
| File | Hides VFS handles behind generation-tagged descriptors and forwards open/close/read/write/seek/stat/readdir/create/mkdir/unlink/rename. | Fixed eight descriptor slots. |
| Userland | Testable command dispatcher. Executes help/info/mem/resource/device/mount/ls/cd/pwd/cat/write/mkdir/rm/mv through service APIs. | Commands are submitted by test RPC, not an interactive terminal; `ls` returns one indexed entry per request and `write` creates a new file. |
| Process | Static MMka process/thread model with PID/TID allocation, parent relation, state, owner, security token, resource block metadata, IPC identity, service permissions, query and lifecycle validation. | It does not dynamically create Microkit PDs/TCBs; those remain statically composed by the system description. Name/enumeration/events/wait timeout are not implemented. |
| Security | User/group registry, group membership, token issue/revoke, object ACL set/check, and VFS authorization RPC. | Caller token is carried in RPC `reserved` and File forwards it to VFS. Current policy uses a bounded object policy and basic read/write rights; path-scoped, service/device/IPC ACL are next scope. |

## Isolation Notes

PCI config I/O is granted only to Device Service. Storage data is private to Storage except for the shared transfer page. RAMFS node contents are private to VFS; File Service and Userland receive only the VFS transfer page. The common RPC page remains writable in every participating PD so the current request/response protocol is not capability-minimal. VFS operations now cross the Security PD before dispatch; denied calls return `RPC_PERMISSION`. Fault monitoring is supplied by Microkit's generated monitor; service restart orchestration is not implemented.
