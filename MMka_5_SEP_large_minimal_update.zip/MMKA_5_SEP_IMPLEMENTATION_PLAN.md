# MMka_5(SEP) Implementation Plan

## 判定基準

- **EXISTING**: 現行コードで実装され、QEMUテストで確認済み
- **PARTIAL**: 一部の経路・固定容量・試験用実装のみ
- **BROKEN**: 実装はあるが、現行ベースラインで再現性または実行に問題がある
- **MISSING**: 現行コードに実装なし
- **[IMPLEMENTED] / [PARTIAL] / [ARCHITECTURAL LIMITATION] / [FUTURE] / [NOT IMPLEMENTED]**: 追加仕様の監査分類。詳細は [MMKA_5_SEP_REAUDIT.md](MMKA_5_SEP_REAUDIT.md)
- **NOT_APPLICABLE**: MMka CoreではなくHeraixOS／アプリケーション側の責務
- **FUTURE**: ARM64/RISC-Vまたは将来フェーズで実装

## 2026-09-28時点の棚卸し

| 要件群 | 番号 | 判定 | 根拠 |
|---|---:|---|---|
| Process / Thread | 1–15 | PARTIAL | PID/TID registry、parent relation、state、owner、token、resource block、IPC identity、service permissions、create/query/thread-query/exitを追加。name/enumeration/events/wait timeoutは未実装 |
| Memory | 16–25 | PARTIAL | 固定16ブロックの4 KiB pool allocationと共有領域を実装。解放、ページング、保護、統計、heapは未実装 |
| Filesystem | 26–39 | PARTIAL | RAMFS、Storage-backed固定ファイル、VFS、File descriptor、mount/path、read/write/seek/stat/readdir/create/mkdir/rename/unlinkを実装。永続FS、ACL、metadata、汎用driverは未実装 |
| System Services | 40–51 | PARTIAL | 静的サービス構成、System/Resource/Device/Storageサービスを実装。依存関係、recovery、configuration DB、power/driver managerは未実装 |
| Security | 52–61 | PARTIAL | User/Group/Tokenとobject ACLのset/check、allow/deny、caller token propagation、VFS認可RPC、non-root read allow/write denyを追加。path-scoped/File execute/service/device/IPC ACLは未完了 |
| macOS系再設計 | 62–80 | MISSING / NOT_APPLICABLE | MMkaはデスクトップ環境ではない。HeraixOS側のWindow/Workspace/Notification/Clipboard/Search等に委譲 |
| Linux/Zorin系再設計 | 81–101 | MISSING / NOT_APPLICABLE | Desktop、Software Center、Package、Network、Bluetooth、Accessibility等はHeraixOS／周辺サービスの責務 |
| Heraix独自基盤 | 102–117 | PARTIAL | versioned RPC ABI、System/Memory/Resource/Device/Storage/VFS/File/Userland公開APIは存在。HAPI、package、discovery、graphics/audio/input/network/device/security/updateは未実装 |
| Diagnostics | 118–132 | PARTIAL | Microkit monitor、serial boot log、QEMU test harness、service markersは存在。Process/Memory/IPC/Device monitor、crash dump、trace、safe mode、recoveryは未実装 |

## ベースライン

- Target: `x86_64_generic + QEMU`
- Build: 全11 PD compile/link、Microkit image生成に成功
- Test: `MMKA SYSTEM TEST: PASS`
- 検証済み: service RPC、ABI validation、memory allocation、PCI discovery、RAM-backed storage、VFS/RAMFS CRUD、generation-tagged file handles、Userland command flow、PID/TID lifecycle/query/resource metadata、user/group/token/ACL allow-deny、VFS caller-token enforcement
- 未検証: 実ハードウェア、永続block device、IRQ/MMIO driver、複数CPU、Security policy、ARM64/RISC-V

## 最小ステップの実装順

1. **P0 — Reproducible build**: ランチャー実行権限、SDK指定、QEMU事前診断を固定する（完了）。
2. **P0 — Core hardening**: ABI境界、channel検証、共有バッファ長、handle generation、path/range検証を各サービスで共通化する。
3. **P1 — Resource lifecycle**: pool block release、service/object handle table、timeout/wait semanticsを追加する。
4. **P1 — Security enforcement**: caller tokenをRPCへ伝播し、VFS/File boundaryでACL checkを必須化する（基本経路完了）。次はpath/node別ACL、File execute、Service/Device/IPC ACL。
5. **P1 — Storage/VFS**: read-only mount、metadata、permission hook、永続backend interfaceを追加する。既存RAMFSは互換経路として保持する。
6. **P3 — Heraix boundary**: HAPI service discovery、package/update contract、hardware/network/input/storage abstractionsを追加する。
7. **P4 — Diagnostics**: structured log、trace buffer、crash/minidump contract、safe/recovery boot policyを追加する。
8. **Future**: x86_64共通APIを維持したまま、`arch/arm64`、`arch/riscv64`へ移植する。

## 製品化ゲート

次の項目が完了するまで「製品化完了」とは判定しない。

- クリーン環境でSDK取得から`./scripts/mmka test`まで再現できる
- 全サービスでinvalid request、size、flags、seq、handle、rangeを網羅的に拒否できる
- QEMUテストに加え、実ハードウェアまたは明示的な非対応宣言がある
- Security/permission、service restart/recovery、persistent storageに実装とテストがある
- API/ABI versioning、license、release artifact、upgrade/rollback手順が揃う

> 本書は未実装機能を実装済みと報告しないための記録です。現行成果物は、MMka 5 Coreの検証済みベースラインであり、132項目すべてを満たす製品版ではありません。
