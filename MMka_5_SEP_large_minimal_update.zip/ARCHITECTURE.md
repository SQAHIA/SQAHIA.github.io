# Architecture

## Layering

```text
Hardware
  -> seL4 kernel
  -> Microkit static composition
  -> Heraix user-space services
  -> Heraix public RPC/API and userland
  -> HeraixOS_Kub and other products
```

seL4 owns capability enforcement, CSpace/VSpace, TCBs, scheduling, IPC, IRQ primitives, isolation and kernel memory primitives. Microkit fixes protection domains, memory regions, channels and device capabilities at composition/build time. Heraix services own policy and higher-level resource, storage, namespace and file behavior. No BSD kernel, VM, scheduler, IPC or kernel device implementation is included.

## Service Graph

```text
                         +-> System Service
                         +-> Memory Service
Heraix Root PD ----------+-> Resource Service
                         +-> Device Service
                         +-> Storage Service <---- VFS Service
                         +-> VFS Service <-------- File Service <---- Userland
                         +-> File Service <--------------------------- Userland
                         +-> Userland
```

RPC requests and responses use the shared `rpc` memory region. File payload/path data uses `vfs_io`; Storage block payloads use `storage_io`. Userland commands are submitted through `userland_io`. Calls are notification-driven and each caller waits for a service response before issuing the next request.

## Memory Layout

| Region | Size | Virtual address | Mapped protection domains |
| --- | ---: | ---: | --- |
| `rpc` | 4 KiB | `0x30000000` | Root and every service |
| `pool` | 64 KiB | `0x31000000` | Root, Memory Service |
| `storage_io` | 4 KiB | `0x32000000` | Root, Storage, VFS |
| `vfs_io` | 4 KiB | `0x33000000` | Root, VFS, File Service, Userland |
| `userland_io` | 4 KiB | `0x34000000` | Root, Userland |

The RPC region is writable by all service endpoints in this initial design. Payload mappings are limited to their participating clients/services. Memory pool allocation is a 16-slot bitmap allocator; Storage owns a separate 64 KiB RAM block array. VFS maps the Storage and VFS payload regions to forward block requests and file data.

## Channel Layout

Channel IDs are local to each protection domain. Root uses: `0` System, `1` Memory, `2` Resource, `3` Device, `4` Storage, `5` VFS, `6` File, `7` Userland. Storage uses channel `0` for Root and `1` for VFS. VFS uses `0` Root, `1` Storage and `2` File Service. File Service uses `0` Root, `1` VFS and `2` Userland. Userland uses `0` Root, `1` System, `2` Memory, `3` Resource, `4` Device and `5` File Service.

Each service has its own protection domain and TCB. QEMU PCI configuration I/O ports `0xcf8-0xcff` are assigned only to Device Service. IRQ and MMIO capabilities are not currently assigned.

## Supported Hardware

- `x86_64_generic` under QEMU, using the repository's seL4 kernel and Microkit SDK 2.3.1.
- Device discovery reads PCI configuration mechanism #1 on bus 0. The tested QEMU machine exposes a PIIX3 ISA bridge (`8086:7000`, BDF `00:01.0`); Device Service registers it and re-reads its live identity on lookup.
- Physical hardware, PCI buses other than bus 0, MMIO access, IRQ handling and non-x86 targets are not verified by the current test.