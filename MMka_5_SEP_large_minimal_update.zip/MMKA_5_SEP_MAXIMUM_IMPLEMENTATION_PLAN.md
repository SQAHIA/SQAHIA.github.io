# MMka_5(SEP) Maximum Implementation Plan

## 0. 目的

現行の `x86_64_generic + Microkit 2.3.1 + seL4 + QEMU` で安全に実装可能なMMka機能を最大限実装する。Microkitの静的PD/TCB構成、seL4 capability境界、既存の共有RPC ABIを維持し、APIだけ・台帳だけ・成功値だけの実装は完成扱いにしない。

## 1. 再監査サマリー

### [IMPLEMENTED]

- Microkit静的構成とRoot/11 PDのboot、build、QEMU regression
- Versioned RPC、shared memory、service channel、error status propagation
- System/Memory/Resource/Device/Storage/VFS/File/Userlandサービス
- RAMFS、Storage-backed system file、file handles、CRUD、seek、stat、readdir
- Process/ThreadのPID/TID、親子関係、状態、owner、security token、resource metadata、IPC identity、service permissions、create/query/thread-query/exit
- User/Group/Token、ACL set/check/revoke
- caller token propagation: Application/Root → File → VFS → Security
- VFS read allow / write denyの実操作強制
- Memory block freeとdouble-free/range rejection、System health集約状態
- ABI/range/handle/generationの基本拒否、QEMU統合テスト

### [PARTIAL]

- Process name、enumeration、state transition、limits、resource accounting、event notification
- Thread enumeration、identity、events
- ACLの固定object policy、path/node別policy、execute、directory traverse
- Service/Device/IPC endpoint permissions
- Memory allocation/statistics: 固定poolのalloc/freeとrange/double-free拒否を実装、ownership/limits/protectionは未完了
- Service lifecycle: 静的登録とRPCは実装、start/stop/recovery/dependency/configurationは未完了
- Diagnostics: boot logとmarkerは実装、structured log/trace/crash dump/monitor APIは未完了
- CLI: Userland command dispatcherは実装、全診断subcommandは未完了

### [NOT IMPLEMENTED]

- 動的Process/ThreadのMicrokit PD/TCB生成
- wait/timeout、multi-core scheduling、IRQ-driven asynchronous queue
- persistent filesystem、一般mount manager、network/socket/DNS
- package install/update/signature、configuration persistence
- GUI/window/display/input系、実機driver、ARM64/RISC-V移植

### [ARCHITECTURAL LIMITATION]

- RuntimeのPD/TCB生成: Microkit system descriptionで静的にcapabilityを構成する設計のため、MMka側で偽装せず、MMka Process/Thread Modelと静的PD/TCB対応情報で代替する。
- seL4 scheduler直接操作: kernel APIではなく、Microkit notification/channelと静的priorityで抽象化する。

### [BLOCKED]

現時点では追加のBLOCKEDは宣言しない。NOT IMPLEMENTED項目の多くは技術的には別サービス・共有領域・静的構成の拡張で実装可能であり、優先順位を付けて実装する。実装不能と判明した時のみ、原因・制約レイヤー・必要条件・MMka代替・将来移植方針を記録する。

## 2. 最大実装フェーズ

### Phase A — Process/Thread OS abstraction

1. Process/Thread name storage and bounded enumeration API
2. Explicit state transition validation: CREATED/RUNNING/BLOCKED/EXITED
3. Process limits and resource accounting with counters
4. Process/Thread information records including static PD/TCB identity mapping
5. Event notification ring buffer and event query API
6. Regression tests for lookup, enumeration, invalid transitions, limits, and event delivery

### Phase B — Security enforcement expansion

1. Replace fixed VFS object with stable path/node object identity
2. File read/write/execute ACLs
3. Directory read/write/traverse ACLs
4. Service connect/call permissions
5. Device access and IPC endpoint permission checks at service boundaries
6. Deny-by-default tests for every new boundary

### Phase C — Service Manager and diagnostics

1. Service registration/discovery/enumeration records
2. Service state, dependency metadata, permission metadata
3. Start/stop requests for statically composed services where Microkit permits notification control
4. Failure detection, health state, recovery policy records; no false claim of dynamic PD restart
5. Structured bounded log ring, service/process/thread/IPC health APIs
6. Userland diagnostic commands connected to real APIs

### Phase D — Memory/VFS/Storage hardening

1. Pool allocation ownership and release
2. Per-process accounting and bounded limits
3. Allocation statistics and invalid-free rejection
4. VFS metadata, mount/unmount state, read-only policy
5. Path-scoped permissions and directory traversal
6. Storage error propagation and recovery metadata

### Phase E — API, packaging, release validation

1. Public headers for all implemented operations
2. ABI compatibility and version tests
3. Clean SDK/build reproduction
4. QEMU regression plus negative/security tests
5. Architecture, API, known issues, BLOCKED, and porting notes
6. Reproducible source package and SHA-256

## 3. 実装順序の理由

Process/Thread identity is required by Security and Service Manager. Security enforcement must precede broad VFS and service expansion. Service diagnostics then make failures observable. Memory/VFS hardening follows because ownership and path identity depend on those records. Network, package, GUI, and physical driver work remain separate product layers unless the current source tree gains the required hardware and protocol contracts.

## 4. Completion gate

A phase is complete only when the call path is connected, errors are enforced, a negative test exists, QEMU regression remains green, and the API/documentation describes actual behavior. The overall project is not called product-complete while PARTIAL or NOT IMPLEMENTED items remain.
