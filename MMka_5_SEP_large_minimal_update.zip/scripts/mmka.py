#!/usr/bin/env python3
import os
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SDK = Path(os.environ.get(
    "MICROKIT_SDK",
    str(ROOT / "microkit-source/release/microkit-sdk-2.3.1")
))
BOARD = os.environ.get("MMKA_BOARD", "x86_64_generic")
CONFIG = os.environ.get("MMKA_CONFIG", "debug")
BUILD = ROOT / "build" / BOARD / CONFIG
SDF = ROOT / "configs/x86_64/core.system"

def run(cmd, *, cwd=None, capture=False, check=True):
    print("+", " ".join(map(str, cmd)))
    return subprocess.run(
        [str(x) for x in cmd],
        cwd=cwd,
        text=True,
        capture_output=capture,
        check=check
    )

def toolchain():
    if BOARD == "x86_64_generic":
        return "x86_64-linux-gnu", "-march=x86-64 -mtune=generic"
    raise SystemExit(f"Unsupported board: {BOARD}")

def build():
    if not (SDK / "bin/microkit").is_file():
        raise SystemExit(
            f"Missing Microkit SDK: {SDK}\n"
            "Set MICROKIT_SDK to an installed Microkit SDK 2.3.1 directory."
        )

    triple, archflags = toolchain()
    cc = f"{triple}-gcc"
    ld = f"{triple}-ld"
    board_dir = SDK / "board" / BOARD / CONFIG
    ldscript = board_dir / "lib/microkit.ld"

    BUILD.mkdir(parents=True, exist_ok=True)

    common = [
        "-nostdlib", "-ffreestanding", "-g", "-O3",
        "-Wall", "-Werror",
        f"-I{ROOT / 'include'}",
        f"-I{board_dir / 'include'}",
        *archflags.split()
    ]

    for name in ("root", "system", "memory", "resource", "device", "storage", "vfs", "file", "userland", "process", "security"):
        src = ROOT / "services" / name / "main.c"
        obj = BUILD / f"{name}.o"
        elf = BUILD / f"{name}.elf"

        run([cc, "-c", *common, src, "-o", obj])
        run([
            ld,
            f"-L{board_dir / 'lib'}",
            obj,
            "-lmicrokit",
            f"-T{ldscript}",
            "-o", elf
        ])

    run([
        SDK / "bin/microkit",
        SDF,
        "--search-path", BUILD,
        "--board", BOARD,
        "--config", CONFIG,
        "-o", BUILD / "loader.img",
        "-r", BUILD / "report.txt"
    ])

    if BOARD == "x86_64_generic":
        kernel = BUILD / "sel4_32.elf"
        if not kernel.is_file():
            raise SystemExit(f"Missing kernel image: {kernel}")

    print("MMKA BUILD OK")

def qemu_cmd():
    if BOARD == "x86_64_generic":
        if shutil.which("qemu-system-x86_64") is None:
            raise SystemExit(
                "Missing qemu-system-x86_64; install QEMU before using run/test."
            )
        return [
            "qemu-system-x86_64",
            "-cpu", "qemu64,+fsgsbase,+pdpe1gb,+xsaveopt,+xsave",
            "-m", "1G",
            "-display", "none",
            "-serial", "stdio",
            "-kernel", BUILD / "sel4_32.elf",
            "-initrd", BUILD / "loader.img"
        ]
    raise SystemExit(f"Unsupported board: {BOARD}")

def test():
    build()

    import subprocess

    log = BUILD / "qemu.log"
    cmd = qemu_cmd()

    print("+", " ".join(map(str, cmd)))

    proc = subprocess.Popen(
        [str(x) for x in cmd],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT
    )

    try:
        raw, _ = proc.communicate(timeout=6)
    except subprocess.TimeoutExpired as e:
        proc.kill()
        raw, _ = proc.communicate()
        if not raw:
            raw = e.stdout or b""

    if isinstance(raw, bytes):
        output = raw.decode("utf-8", errors="replace")
    else:
        output = raw or ""

    log.write_text(output)

    markers = [
        "HERAIX_ROOT_OK",
        "SYSTEM_SERVICE_OK",
        "MEMORY_SERVICE_OK",
        "RESOURCE_SERVICE_OK",
        "DEVICE_SERVICE_OK",
        "DEVICE_DISCOVERY_OK",
        "DEVICE_REGISTRATION_OK",
        "SYSTEM_API_OK",
        "SYSTEM_HEALTH_OK",
        "MEMORY_ALLOC_OK",
        "MEMORY_FREE_OK",
        "RESOURCE_API_OK",
        "DEVICE_API_OK",
        "DEVICE_ACCESS_OK",
        "DEVICE_BAD_REQUEST_REJECTED",
        "STORAGE_SERVICE_OK",
        "STORAGE_API_OK",
        "STORAGE_BLOCK_INFO_OK",
        "STORAGE_BLOCK_WRITE_OK",
        "STORAGE_BLOCK_READ_OK",
        "STORAGE_BAD_RANGE_REJECTED",
        "VFS_SERVICE_OK",
        "VFS_MOUNT_OK",
        "VFS_READDIR_OK",
        "VFS_OPEN_OK",
        "VFS_WRITE_OK",
        "VFS_SEEK_OK",
        "VFS_READ_OK",
        "VFS_STAT_OK",
        "VFS_CLOSE_OK",
        "VFS_BAD_HANDLE_REJECTED",
        "VFS_OK",
        "RAMFS_MKDIR_OK",
        "RAMFS_CREATE_OK",
        "RAMFS_WRITE_OK",
        "RAMFS_READ_OK",
        "RAMFS_STAT_OK",
        "RAMFS_READDIR_OK",
        "RAMFS_RENAME_OK",
        "RAMFS_UNLINK_OK",
        "RAMFS_OK",
        "FILE_SERVICE_OK",
        "FILE_API_OK",
        "FILE_CREATE_OK",
        "FILE_OPEN_OK",
        "FILE_WRITE_OK",
        "FILE_READ_OK",
        "FILE_SEEK_OK",
        "FILE_STAT_OK",
        "FILE_CLOSE_OK",
        "FILE_BAD_HANDLE_REJECTED",
        "FILE_STALE_HANDLE_REJECTED",
        "FILE_READDIR_OK",
        "FILE_RENAME_OK",
        "FILE_UNLINK_OK",
        "FILE_OK",
        "ABI_INVALID_REQUEST_REJECTED",
        "ABI_INVALID_SIZE_REJECTED",
        "ABI_INVALID_FLAGS_REJECTED",
        "USERLAND_SERVICE_OK",
        "USERLAND_HELP_OK",
        "USERLAND_MKDIR_OK",
        "USERLAND_WRITE_OK",
        "USERLAND_CAT_OK",
        "USERLAND_LS_OK",
        "USERLAND_MV_OK",
        "USERLAND_RM_OK",
        "USERLAND_CD_OK",
        "USERLAND_PWD_OK",
        "USERLAND_MOUNT_OK",
        "USERLAND_INFO_OK",
        "USERLAND_MEM_OK",
        "USERLAND_RESOURCE_OK",
        "USERLAND_DEVICE_OK",
        "USERLAND_OK",
        "PROCESS_SERVICE_OK",
        "PROCESS_CREATE_OK",
        "PROCESS_ENUMERATION_OK",
        "PROCESS_EVENT_QUERY_OK",
        "THREAD_CREATE_OK",
        "THREAD_QUERY_OK",
        "PROCESS_QUERY_OK",
        "THREAD_EXIT_OK",
        "PROCESS_EXIT_OK",
        "SECURITY_SERVICE_OK",
        "USER_CREATE_OK",
        "GROUP_CREATE_OK",
        "GROUP_MEMBER_OK",
        "TOKEN_ISSUE_OK",
        "ACL_SET_OK",
        "ACL_ALLOW_OK",
        "ACL_DENY_OK",
        "SECURITY_ACL_OK",
        "VFS_ACL_READ_ALLOW_OK",
        "VFS_ACL_WRITE_DENY_OK",
        "VFS_ACL_ENFORCEMENT_OK",
        "CORE_OK"
    ]

    failed = False

    for marker in markers:
        if marker in output:
            print(f"[PASS] {marker}")
        else:
            print(f"[FAIL] {marker}")
            failed = True

    if failed:
        print("\n=== QEMU OUTPUT ===")
        print(output)
        print(f"Log: {log}")
        raise SystemExit(1)

    print("\nMMKA SYSTEM TEST: PASS")

def run_qemu():
    build()
    subprocess.run(qemu_cmd(), check=False)

def clean():
    shutil.rmtree(ROOT / "build", ignore_errors=True)
    print("MMKA CLEAN OK")

if __name__ == "__main__":
    if len(sys.argv) != 2 or sys.argv[1] not in {"build","run","test","clean"}:
        print("Usage: ./scripts/mmka {build|run|test|clean}")
        raise SystemExit(2)

    {"build": build, "run": run_qemu, "test": test, "clean": clean}[sys.argv[1]]()
