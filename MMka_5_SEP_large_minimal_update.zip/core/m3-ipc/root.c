#include <microkit.h>

#define CH_SYSTEM ((microkit_channel)0)

void init(void)
{
    microkit_dbg_puts("HERAIX_ROOT_OK\n");
    microkit_notify(CH_SYSTEM);
}

void notified(microkit_channel ch)
{
    if (ch == CH_SYSTEM) {
        microkit_dbg_puts("IPC_OK\n");
    }
}
