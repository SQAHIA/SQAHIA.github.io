#include <microkit.h>

#define CH_ROOT ((microkit_channel)0)

void init(void)
{
    microkit_dbg_puts("SYSTEM_SERVICE_OK\n");
}

void notified(microkit_channel ch)
{
    if (ch == CH_ROOT) {
        microkit_dbg_puts("SYSTEM_SERVICE: request received\n");
        microkit_notify(CH_ROOT);
    }
}
