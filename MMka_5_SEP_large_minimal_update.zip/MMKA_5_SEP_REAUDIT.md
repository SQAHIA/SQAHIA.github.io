# MMka_5(SEP) 再監査報告

## 監査対象

`pasted_content_2.txt` と受信済みの `pasted_content_3.txt` に記載された Process / Thread / Security / VFS 要求を、現行の `x86_64_generic + Microkit 2.3.1 + QEMU` 実装に照合した。

`pasted_content_3.txt` は受信データが248行目の `- S` で途切れているため、IPC章以降の要求は未監査である。

## 分類

| 分類 | 対象 | 根拠 |
|---|---|---|
| **[IMPLEMENTED]** | PID/TID登録、親子関係、Process/Thread状態、Process/Thread lookup、Process/Thread exit、owner、security token、resource block metadata、IPC identity、service permission metadata、caller tokenのRPC保持、VFS認可RPC、root/non-rootのVFS allow/deny | QEMUで専用マーカーを検証済み。`MMKA SYSTEM TEST: PASS` |
| **[IMPLEMENTED]** | User/Group/Token、ACL set/check、token revoke、VFS read/write ACL gate | VFSが操作前にSecurity Serviceへ`OP_ACL_CHECK`を発行し、deny時はFile/VFS操作へ進まない |
| **[PARTIAL]** | Process name、process/thread enumeration、state transition API、resource accountingの詳細、directory traversalのpath単位ACL、File execute ACL、service connect/call ACL、Device/IPC endpoint ACL | 現在は固定容量、単一のVFS policy object、基本rightsに限定 |
| **[PARTIAL]** | Microkit PD/TCBとの対応 | MMka PID/TIDと静的PD/TCBを分離して定義済みだが、対応表API・enumeration・event notificationは未提供 |
| **[NOT IMPLEMENTED]** | 動的PD/TCB生成、wait/timeout、process/thread event stream、service restart/recovery、persistent storage、完全なpath-scoped ACL、hardware-backed identity | 現行ソースに機能なし |
| **[ARCHITECTURAL LIMITATION]** | 実行時のMicrokit PD/TCB生成、seL4 schedulerの直接操作 | Microkitの静的system descriptionとseL4権限モデルに依存するため、MMka独自のProcess/Thread Modelで代替する |
| **[FUTURE]** | ARM64/RISC-V移植、実ハードウェアdriver、複数CPU | 現ターゲット外 |

## 今回の接続実装

```text
Caller
  -> RPC reserved (caller token)
  -> File Service (tokenを保持してVFSへ転送)
  -> VFS
  -> Security Service / OP_ACL_CHECK
  -> allow: File/VFS operation
  -> deny: RPC_PERMISSION
```

`reserved == 0` は互換性のためroot token `1`として扱う。明示的なcallerは `heraix_rpc_set_token()` でtokenを設定できる。

## 検証済み拒否経路

- root tokenで既存VFS/File/RAMFS回帰操作が成功
- non-root tokenでVFS directory readが成功
- 同一non-root tokenでwrite系VFS操作が`RPC_PERMISSION`となる
- Security ACLのallow/deny単体判定も成功

## 残課題

1. Process name、enumeration、limits、イベント通知をAPI化する。
2. VFS object keyを固定値からpath/node identityへ拡張する。
3. File read/write/execute、directory traverse、service access、device accessへ個別ACLを拡張する。
4. Service Managerの登録・lookup・state・failure/recoveryを実装する。
5. 受信が途切れたIPC章以降の要求を再受信後に監査する。

現時点で「製品化完了」とは判定しない。実装済み経路と制約・未実装範囲を分離して記録する。
