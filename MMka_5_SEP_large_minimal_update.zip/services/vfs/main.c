#include <microkit.h>
#include "heraix_rpc.h"
#include "heraix/api.h"
#include "heraix/security.h"
#include "compat/freebsd_stailq.h"

#define CH_ROOT    ((microkit_channel)0)
#define CH_STORAGE ((microkit_channel)1)
#define CH_FILE    ((microkit_channel)2)
#define CH_SECURITY ((microkit_channel)3)
#define VFS_HANDLE_COUNT 8U
#define RAMFS_NODE_COUNT 16U
#define RAMFS_PATH_SIZE 128U
#define VFS_OPEN_READ  1U
#define VFS_OPEN_WRITE 2U
#define VFS_NODE_FILE  1U
#define VFS_NODE_DIR   2U

typedef struct {
    uint32_t open;
    uint32_t flags;
    uint64_t position;
    uint64_t generation;
    uint32_t node_index;
} vfs_handle_t;

typedef struct {
    const char *prefix;
    uint32_t storage_block;
} vfs_mount_t;

typedef struct ramfs_node {
    uint32_t used;
    uint32_t type;
    uint32_t size;
    char path[RAMFS_PATH_SIZE];
    uint8_t data[HERAIX_BLOCK_SIZE];
    STAILQ_ENTRY(ramfs_node) links;
} ramfs_node_t;

STAILQ_HEAD(ramfs_node_queue, ramfs_node);

static volatile heraix_rpc_t *rpc =
    (volatile heraix_rpc_t *)HERAIX_RPC_VADDR;
static volatile uint8_t *io_buffer =
    (volatile uint8_t *)HERAIX_STORAGE_IO_VADDR;
static volatile uint8_t *vfs_buffer =
    (volatile uint8_t *)HERAIX_VFS_IO_VADDR;
static const vfs_mount_t root_mount = {"/", 0};
static vfs_handle_t handles[VFS_HANDLE_COUNT];
static ramfs_node_t ramfs_nodes[RAMFS_NODE_COUNT];
static struct ramfs_node_queue active_nodes;
static struct ramfs_node_queue free_nodes;

static uint32_t pending_opcode;
static uint32_t pending_handle;
static uint64_t pending_length;
static uint64_t pending_position;
static microkit_channel current_client_channel;
static uint32_t pending_authorized;
static uint64_t pending_arg0;
static uint64_t pending_arg1;
static uint64_t pending_arg2;

static uint32_t text_length(const char *text)
{
    uint32_t length = 0;
    while (text[length] != '\0') {
        ++length;
    }
    return length;
}

static int text_equal(const char *left, const char *right)
{
    uint32_t index = 0;
    while (left[index] != '\0' && right[index] != '\0') {
        if (left[index] != right[index]) {
            return 0;
        }
        ++index;
    }
    return left[index] == right[index];
}

static int buffer_string(uint32_t offset, char *output, uint32_t capacity)
{
    for (uint32_t index = 0; index < capacity; ++index) {
        output[index] = (char)vfs_buffer[offset + index];
        if (output[index] == '\0') {
            return 1;
        }
    }
    return 0;
}

static void buffer_write_string(uint32_t offset, const char *text)
{
    uint32_t index = 0;
    while (text[index] != '\0' && offset + index < HERAIX_VFS_DATA_OFFSET - 1) {
        vfs_buffer[offset + index] = (uint8_t)text[index];
        ++index;
    }
    vfs_buffer[offset + index] = 0;
}

static int path_is(const char *expected)
{
    uint32_t index = 0;
    while (expected[index] != '\0' && index < HERAIX_VFS_DATA_OFFSET - 1) {
        if (vfs_buffer[HERAIX_VFS_PATH_OFFSET + index] !=
            (uint8_t)expected[index]) {
            return 0;
        }
        ++index;
    }
    return expected[index] == '\0' &&
           vfs_buffer[HERAIX_VFS_PATH_OFFSET + index] == 0;
}

static int ramfs_path_valid(const char *path)
{
    if (path[0] != '/' || path[1] != 't' || path[2] != 'm' ||
        path[3] != 'p' || path[4] != '/') {
        return 0;
    }
    uint32_t length = text_length(path);
    if (length < 6 || length >= RAMFS_PATH_SIZE || path[length - 1] == '/') {
        return 0;
    }
    for (uint32_t index = 1; index < length; ++index) {
        if (path[index] == '/' &&
            (path[index - 1] == '/' || path[index + 1] == '\0')) {
            return 0;
        }
        if (path[index] == '.' &&
            (path[index + 1] == '/' || path[index + 1] == '\0')) {
            return 0;
        }
    }
    return 1;
}

static int ramfs_find(const char *path)
{
    ramfs_node_t *node;
    STAILQ_FOREACH(node, &active_nodes, links) {
        if (text_equal(node->path, path)) {
            return (int)(node - ramfs_nodes);
        }
    }
    return -1;
}

static int path_is_directory(const char *path)
{
    if (text_equal(path, "/") || text_equal(path, "/system") ||
        text_equal(path, "/tmp")) {
        return 1;
    }
    int index = ramfs_find(path);
    return index >= 0 && ramfs_nodes[index].type == VFS_NODE_DIR;
}

static int parent_directory_exists(const char *path)
{
    char parent[RAMFS_PATH_SIZE];
    uint32_t length = text_length(path);
    uint32_t slash = length;
    while (slash > 0 && path[slash - 1] != '/') {
        --slash;
    }
    if (slash <= 1 || slash >= sizeof(parent)) {
        return 0;
    }
    uint32_t parent_length = slash - 1;
    if (parent_length == 0) {
        parent[parent_length++] = '/';
    } else {
        for (uint32_t index = 0; index < parent_length; ++index) {
            parent[index] = path[index];
        }
    }
    parent[parent_length] = '\0';
    return path_is_directory(parent);
}

static int is_direct_child(const char *directory, const char *path)
{
    uint32_t directory_length = text_length(directory);
    uint32_t index = 0;
    if (!text_equal(directory, "/") && path[directory_length] != '/') {
        return 0;
    }
    while (index < directory_length && directory[index] == path[index]) {
        ++index;
    }
    if (index != directory_length) {
        return 0;
    }
    uint32_t child_start = directory_length;
    if (!text_equal(directory, "/")) {
        if (path[child_start] != '/') {
            return 0;
        }
        ++child_start;
    }
    if (path[child_start] == '\0') {
        return 0;
    }
    for (index = child_start; path[index] != '\0'; ++index) {
        if (path[index] == '/') {
            return 0;
        }
    }
    return 1;
}

static int ramfs_create(const char *path, uint32_t type)
{
    if (!ramfs_path_valid(path) || !parent_directory_exists(path)) {
        return RPC_NOT_FOUND;
    }
    if (ramfs_find(path) >= 0) {
        return RPC_ALREADY_EXISTS;
    }
    ramfs_node_t *node = STAILQ_FIRST(&free_nodes);
    if (node == 0) {
        return RPC_NO_MEMORY;
    }
    STAILQ_REMOVE_HEAD(&free_nodes, links);
    node->used = 1;
    node->type = type;
    node->size = 0;
    for (uint32_t byte = 0; byte < HERAIX_BLOCK_SIZE; ++byte) {
        node->data[byte] = 0;
    }
    uint32_t path_length = text_length(path);
    for (uint32_t character = 0; character <= path_length; ++character) {
        node->path[character] = path[character];
    }
    STAILQ_INSERT_TAIL(&active_nodes, node, links);
    rpc->value0 = (uint64_t)(node - ramfs_nodes) + 1;
    return RPC_OK;
}

static int ramfs_has_children(const char *path)
{
    ramfs_node_t *node;
    STAILQ_FOREACH(node, &active_nodes, links) {
        if (is_direct_child(path, node->path)) {
            return 1;
        }
    }
    return 0;
}

static int path_is_descendant(const char *parent, const char *path)
{
    uint32_t length = text_length(parent);
    uint32_t index = 0;
    while (index < length && parent[index] == path[index]) {
        ++index;
    }
    return index == length && path[length] == '/';
}

static void respond(int32_t status)
{
    rpc->service = SVC_VFS;
    rpc->status = status;
    microkit_notify(current_client_channel);
}

static int vfs_channel_valid(microkit_channel ch)
{
    if ((ch != CH_ROOT && ch != CH_FILE) ||
        !heraix_rpc_valid_request(rpc, SVC_VFS)) {
        if (ch == CH_ROOT || ch == CH_FILE) {
            current_client_channel = ch;
            respond(RPC_BAD_REQUEST);
        }
        return 0;
    }
    return 1;
}

static int handle_index(uint64_t handle)
{
    uint64_t slot = handle & 0xffu;
    uint64_t generation = handle >> 8;
    if (slot == 0 || slot > VFS_HANDLE_COUNT || generation == 0 ||
        !handles[slot - 1].open ||
        handles[slot - 1].generation != generation) {
        return -1;
    }
    return (int)(slot - 1);
}

static void storage_request(uint32_t opcode, uint64_t length, uint64_t offset)
{
    rpc->service = SVC_STORAGE;
    rpc->opcode = opcode;
    rpc->arg0 = root_mount.storage_block;
    rpc->arg1 = length;
    rpc->arg2 = offset;
    microkit_notify(CH_STORAGE);
}

void init(void)
{
    STAILQ_INIT(&active_nodes);
    STAILQ_INIT(&free_nodes);
    for (uint32_t index = 0; index < RAMFS_NODE_COUNT; ++index) {
        ramfs_nodes[index].used = 0;
        STAILQ_INSERT_TAIL(&free_nodes, &ramfs_nodes[index], links);
    }
    (void)root_mount;
}

void notified(microkit_channel ch)
{
    if (ch == CH_STORAGE) {
        if (rpc->service != SVC_STORAGE || rpc->seq == 0) {
            rpc->service = SVC_VFS;
            respond(RPC_BAD_REQUEST);
            return;
        }

        int32_t status = rpc->status;
        rpc->service = SVC_VFS;
        rpc->opcode = pending_opcode;
        if (status != RPC_OK) {
            respond(status);
            return;
        }

        vfs_handle_t *handle = &handles[pending_handle];
        if (pending_opcode == OP_VFS_READ) {
            for (uint64_t byte = 0; byte < pending_length; ++byte) {
                vfs_buffer[HERAIX_VFS_DATA_OFFSET + byte] = io_buffer[byte];
            }
        } else {
            rpc->value0 = pending_length;
        }
        handle->position = pending_position + pending_length;
        respond(RPC_OK);
        return;
    }

    if (ch == CH_SECURITY) {
        if (!heraix_rpc_valid_request(rpc, SVC_SECURITY) || rpc->seq == 0) {
            rpc->service = SVC_VFS;
            rpc->opcode = pending_opcode;
            respond(RPC_BAD_REQUEST);
            return;
        }
        int32_t status = rpc->status;
        rpc->service = SVC_VFS;
        rpc->opcode = pending_opcode;
        if (status != RPC_OK) {
            respond(status);
            return;
        }
        rpc->arg0 = pending_arg0;
        rpc->arg1 = pending_arg1;
        rpc->arg2 = pending_arg2;
        pending_authorized = 1;
        ch = current_client_channel;
    }

    if (!vfs_channel_valid(ch)) {
        return;
    }
    current_client_channel = ch;

    if ((ch == CH_ROOT || ch == CH_FILE) && !pending_authorized) {
        uint32_t rights = HERAIX_RIGHT_READ;
        if (rpc->opcode == OP_VFS_OPEN) {
            rights = 0;
            if (rpc->arg0 & VFS_OPEN_READ) rights |= HERAIX_RIGHT_READ;
            if (rpc->arg0 & VFS_OPEN_WRITE) rights |= HERAIX_RIGHT_WRITE;
        } else if (rpc->opcode == OP_VFS_WRITE ||
                   rpc->opcode == OP_VFS_CREATE ||
                   rpc->opcode == OP_VFS_MKDIR ||
                   rpc->opcode == OP_VFS_UNLINK ||
                   rpc->opcode == OP_VFS_RENAME) {
            rights = HERAIX_RIGHT_WRITE;
        }
        pending_opcode = rpc->opcode;
        pending_arg0 = rpc->arg0;
        pending_arg1 = rpc->arg1;
        pending_arg2 = rpc->arg2;
        rpc->service = SVC_SECURITY;
        rpc->opcode = OP_ACL_CHECK;
        rpc->arg0 = rpc->reserved == 0 ? HERAIX_TOKEN_ROOT : rpc->reserved;
        rpc->arg1 = HERAIX_VFS_OBJECT;
        rpc->arg2 = rights;
        microkit_notify(CH_SECURITY);
        return;
    }
    pending_authorized = 0;

    if (rpc->opcode == OP_VFS_MKDIR || rpc->opcode == OP_VFS_CREATE) {
        char path[RAMFS_PATH_SIZE];
        if (!buffer_string(HERAIX_VFS_PATH_OFFSET, path, sizeof(path))) {
            respond(RPC_BAD_REQUEST);
            return;
        }
        int status = ramfs_create(path, rpc->opcode == OP_VFS_MKDIR ?
                                  VFS_NODE_DIR : VFS_NODE_FILE);
        respond(status);
        return;
    }

    if (rpc->opcode == OP_VFS_UNLINK) {
        char path[RAMFS_PATH_SIZE];
        if (!buffer_string(HERAIX_VFS_PATH_OFFSET, path, sizeof(path))) {
            respond(RPC_BAD_REQUEST);
            return;
        }
        int index = ramfs_find(path);
        if (index < 0) {
            respond(RPC_NOT_FOUND);
            return;
        }
        if ((ramfs_nodes[index].type == VFS_NODE_DIR &&
             ramfs_has_children(path))) {
            respond(RPC_PERMISSION);
            return;
        }
        for (uint32_t handle = 0; handle < VFS_HANDLE_COUNT; ++handle) {
            if (handles[handle].open && handles[handle].node_index == (uint32_t)index) {
                respond(RPC_PERMISSION);
                return;
            }
        }
        ramfs_node_t *node = &ramfs_nodes[index];
        STAILQ_REMOVE(&active_nodes, node, ramfs_node, links);
        node->used = 0;
        node->size = 0;
        node->path[0] = '\0';
        for (uint32_t byte = 0; byte < HERAIX_BLOCK_SIZE; ++byte) {
            node->data[byte] = 0;
        }
        STAILQ_INSERT_TAIL(&free_nodes, node, links);
        respond(RPC_OK);
        return;
    }

    if (rpc->opcode == OP_VFS_RENAME) {
        char old_path[RAMFS_PATH_SIZE];
        char new_path[RAMFS_PATH_SIZE];
        if (!buffer_string(HERAIX_VFS_PATH_OFFSET, old_path, sizeof(old_path)) ||
            !buffer_string(HERAIX_VFS_DATA_OFFSET, new_path, sizeof(new_path)) ||
            !ramfs_path_valid(new_path) || !parent_directory_exists(new_path)) {
            respond(RPC_NOT_FOUND);
            return;
        }
        int index = ramfs_find(old_path);
        if (index < 0) {
            respond(RPC_NOT_FOUND);
            return;
        }
        if (ramfs_find(new_path) >= 0) {
            respond(RPC_ALREADY_EXISTS);
            return;
        }
        if (path_is_descendant(old_path, new_path)) {
            respond(RPC_INVALID_RANGE);
            return;
        }
        uint32_t old_length = text_length(old_path);
        uint32_t new_length = text_length(new_path);
        ramfs_node_t *node;
        STAILQ_FOREACH(node, &active_nodes, links) {
            if (!text_equal(node->path, old_path) &&
                !path_is_descendant(old_path, node->path)) {
                continue;
            }
            uint32_t suffix_length = text_length(node->path + old_length);
            if (new_length + suffix_length >= RAMFS_PATH_SIZE) {
                respond(RPC_INVALID_RANGE);
                return;
            }
        }
        STAILQ_FOREACH(node, &active_nodes, links) {
            if (!text_equal(node->path, old_path) &&
                !path_is_descendant(old_path, node->path)) {
                continue;
            }
            uint32_t suffix_length = text_length(node->path + old_length);
            char suffix[RAMFS_PATH_SIZE];
            for (uint32_t byte = 0; byte <= suffix_length; ++byte) {
                suffix[byte] = node->path[old_length + byte];
            }
            for (uint32_t byte = 0; byte < new_length; ++byte) {
                node->path[byte] = new_path[byte];
            }
            for (uint32_t byte = 0; byte <= suffix_length; ++byte) {
                node->path[new_length + byte] = suffix[byte];
            }
        }
        respond(RPC_OK);
        return;
    }

    if (rpc->opcode == OP_VFS_READDIR) {
        char path[RAMFS_PATH_SIZE];
        if (!buffer_string(HERAIX_VFS_PATH_OFFSET, path, sizeof(path)) ||
            !path_is_directory(path)) {
            respond(RPC_NOT_FOUND);
            return;
        }
        uint64_t requested_index = rpc->arg0;
        uint64_t found_index = 0;
        if (text_equal(path, "/") && requested_index == found_index) {
            buffer_write_string(HERAIX_VFS_PATH_OFFSET, "system");
        } else if (text_equal(path, "/") && requested_index == ++found_index) {
            buffer_write_string(HERAIX_VFS_PATH_OFFSET, "tmp");
        } else if (text_equal(path, "/system") && requested_index == 0) {
            buffer_write_string(HERAIX_VFS_PATH_OFFSET, "boot");
        } else {
            int emitted = 0;
            ramfs_node_t *node;
            STAILQ_FOREACH(node, &active_nodes, links) {
                if (!is_direct_child(path, node->path)) {
                    continue;
                }
                if (found_index++ == requested_index) {
                    uint32_t start = text_length(path);
                    if (!text_equal(path, "/")) {
                        ++start;
                    }
                    buffer_write_string(HERAIX_VFS_PATH_OFFSET,
                                        node->path + start);
                    emitted = 1;
                    break;
                }
            }
            if (!emitted) {
                respond(RPC_NOT_FOUND);
                return;
            }
        }
        rpc->value0 = 1;
        rpc->value1 = VFS_NODE_DIR;
        respond(RPC_OK);
        return;
    }

    if (rpc->opcode == OP_VFS_STAT) {
        char path[RAMFS_PATH_SIZE];
        if (!buffer_string(HERAIX_VFS_PATH_OFFSET, path, sizeof(path))) {
            respond(RPC_BAD_REQUEST);
            return;
        }
        if (path_is("/") || path_is("/system")) {
            rpc->value0 = 0;
            rpc->value1 = VFS_NODE_DIR;
        } else if (path_is("/system/boot")) {
            rpc->value0 = HERAIX_BLOCK_SIZE;
            rpc->value1 = VFS_NODE_FILE;
        } else if (text_equal(path, "/tmp")) {
            rpc->value0 = 0;
            rpc->value1 = VFS_NODE_DIR;
        } else {
            int index = ramfs_find(path);
            if (index < 0) {
                respond(RPC_NOT_FOUND);
                return;
            }
            rpc->value0 = ramfs_nodes[index].size;
            rpc->value1 = ramfs_nodes[index].type;
        }
        respond(RPC_OK);
        return;
    }

    if (rpc->opcode == OP_VFS_OPEN) {
        char path[RAMFS_PATH_SIZE];
        if (!buffer_string(HERAIX_VFS_PATH_OFFSET, path, sizeof(path))) {
            respond(RPC_BAD_REQUEST);
            return;
        }
        int node_index = text_equal(path, "/system/boot") ?
                         (int)RAMFS_NODE_COUNT : ramfs_find(path);
        if (node_index < 0 ||
            (node_index < (int)RAMFS_NODE_COUNT &&
             ramfs_nodes[node_index].type != VFS_NODE_FILE)) {
            respond(RPC_NOT_FOUND);
            return;
        }
        if ((rpc->arg0 & (VFS_OPEN_READ | VFS_OPEN_WRITE)) == 0 ||
            (rpc->arg0 & ~(VFS_OPEN_READ | VFS_OPEN_WRITE)) != 0) {
            respond(RPC_PERMISSION);
            return;
        }
        for (uint32_t index = 0; index < VFS_HANDLE_COUNT; ++index) {
            if (!handles[index].open) {
                handles[index].open = 1;
                handles[index].flags = (uint32_t)rpc->arg0;
                handles[index].position = 0;
                handles[index].node_index = (uint32_t)node_index;
                ++handles[index].generation;
                if (handles[index].generation == 0) {
                    ++handles[index].generation;
                }
                rpc->value0 = (handles[index].generation << 8) | (index + 1);
                respond(RPC_OK);
                return;
            }
        }
        respond(RPC_NO_MEMORY);
        return;
    }

    int index = handle_index(rpc->arg0);
    if (index < 0) {
        respond(RPC_INVALID_HANDLE);
        return;
    }
    vfs_handle_t *handle = &handles[index];

    if (rpc->opcode == OP_VFS_CLOSE) {
        handle->open = 0;
        respond(RPC_OK);
        return;
    }

    if (rpc->opcode == OP_VFS_SEEK) {
        if (rpc->arg1 > HERAIX_BLOCK_SIZE) {
            respond(RPC_INVALID_RANGE);
            return;
        }
        handle->position = rpc->arg1;
        rpc->value0 = handle->position;
        respond(RPC_OK);
        return;
    }

    if (rpc->opcode != OP_VFS_READ && rpc->opcode != OP_VFS_WRITE) {
        respond(RPC_BAD_REQUEST);
        return;
    }
    if ((rpc->opcode == OP_VFS_READ && !(handle->flags & VFS_OPEN_READ)) ||
        (rpc->opcode == OP_VFS_WRITE && !(handle->flags & VFS_OPEN_WRITE))) {
        respond(RPC_PERMISSION);
        return;
    }

    uint64_t length = rpc->arg1;
    uint64_t file_size = handle->node_index == RAMFS_NODE_COUNT ?
                         HERAIX_BLOCK_SIZE :
                         ramfs_nodes[handle->node_index].size;
    uint64_t transfer_length = length;
    if (rpc->opcode == OP_VFS_READ && handle->position >= file_size) {
        rpc->value0 = 0;
        respond(RPC_OK);
        return;
    }
    if (rpc->opcode == OP_VFS_READ && transfer_length > file_size - handle->position) {
        transfer_length = file_size - handle->position;
    }
    if (length == 0 || length > HERAIX_BLOCK_SIZE ||
        handle->position > HERAIX_BLOCK_SIZE ||
        (rpc->opcode == OP_VFS_WRITE &&
         length > HERAIX_BLOCK_SIZE - handle->position)) {
        respond(RPC_INVALID_RANGE);
        return;
    }
    if (handle->node_index != RAMFS_NODE_COUNT) {
        ramfs_node_t *node = &ramfs_nodes[handle->node_index];
        if (rpc->opcode == OP_VFS_WRITE) {
            for (uint64_t byte = 0; byte < transfer_length; ++byte) {
                node->data[handle->position + byte] =
                    vfs_buffer[HERAIX_VFS_DATA_OFFSET + byte];
            }
            if (handle->position + transfer_length > node->size) {
                node->size = (uint32_t)(handle->position + transfer_length);
            }
        } else {
            for (uint64_t byte = 0; byte < transfer_length; ++byte) {
                vfs_buffer[HERAIX_VFS_DATA_OFFSET + byte] =
                    node->data[handle->position + byte];
            }
        }
        handle->position += transfer_length;
        rpc->value0 = transfer_length;
        respond(RPC_OK);
        return;
    }
    if (rpc->opcode == OP_VFS_WRITE) {
        for (uint64_t byte = 0; byte < transfer_length; ++byte) {
            io_buffer[byte] = vfs_buffer[HERAIX_VFS_DATA_OFFSET + byte];
        }
    }

    pending_opcode = rpc->opcode;
    pending_handle = (uint32_t)index;
    pending_length = transfer_length;
    pending_position = handle->position;
    storage_request(rpc->opcode == OP_VFS_READ ? OP_BLOCK_READ : OP_BLOCK_WRITE,
                    transfer_length, handle->position);
}
