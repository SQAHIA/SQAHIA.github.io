#include <microkit.h>
#include "heraix_rpc.h"
#include "heraix/api.h"
#include "heraix/system.h"
#include "heraix/memory.h"
#include "heraix/resource.h"
#include "heraix/device.h"
#include "heraix/storage.h"
#include "heraix/fs.h"
#include "heraix/file.h"
#include "heraix/process.h"
#include "heraix/security.h"

#define CH_SYSTEM   ((microkit_channel)0)
#define CH_MEMORY   ((microkit_channel)1)
#define CH_RESOURCE ((microkit_channel)2)
#define CH_DEVICE   ((microkit_channel)3)
#define CH_STORAGE  ((microkit_channel)4)
#define CH_VFS      ((microkit_channel)5)
#define CH_FILE     ((microkit_channel)6)
#define CH_USERLAND ((microkit_channel)7)
#define CH_PROCESS  ((microkit_channel)8)
#define CH_SECURITY ((microkit_channel)9)

static volatile heraix_rpc_t *rpc =
    (volatile heraix_rpc_t *)HERAIX_RPC_VADDR;

static volatile uint8_t *pool =
    (volatile uint8_t *)HERAIX_POOL_VADDR;
static volatile uint8_t *storage_io =
    (volatile uint8_t *)HERAIX_STORAGE_IO_VADDR;
static volatile uint8_t *vfs_io =
    (volatile uint8_t *)HERAIX_VFS_IO_VADDR;
static volatile uint8_t *userland_io =
    (volatile uint8_t *)HERAIX_USERLAND_IO_VADDR;

static uint32_t seq;
static uint32_t ramfs_test_state;
static uint32_t file_test_state;
static uint32_t userland_test_state;
static uint64_t vfs_handle;
static uint64_t file_descriptor;
static uint64_t stale_file_descriptor;
static uint32_t process_test_state;
static uint32_t managed_pid;
static uint32_t managed_tid;
static uint32_t managed_thread;
static uint32_t security_test_state;
static uint32_t security_token;
static uint32_t vfs_acl_test_state;
static uint64_t allocated_memory_offset;

static void req(uint32_t service, uint32_t opcode, uint64_t arg0, uint64_t arg1);

static void set_vfs_string(uint32_t offset, const char *text)
{
    uint32_t index = 0;
    while (text[index] != '\0' && offset + index < HERAIX_BLOCK_SIZE - 1) {
        vfs_io[offset + index] = (uint8_t)text[index];
        ++index;
    }
    vfs_io[offset + index] = 0;
}

static void set_vfs_path(const char *path)
{
    set_vfs_string(HERAIX_VFS_PATH_OFFSET, path);
}

static void run_shell_command(const char *command)
{
    uint32_t index = 0;
    while (index < HERAIX_VFS_DATA_OFFSET && command[index] != '\0') {
        userland_io[index] = (uint8_t)command[index];
        ++index;
    }
    userland_io[index] = 0;
    req(SVC_USERLAND, OP_USERLAND_EXEC, 0, 0);
    microkit_notify(CH_USERLAND);
}

static int userland_output_matches(const char *expected)
{
    uint32_t index = 0;
    while (expected[index] != '\0') {
        if (userland_io[HERAIX_USERLAND_OUTPUT_OFFSET + index] !=
            (uint8_t)expected[index]) {
            return 0;
        }
        ++index;
    }
    return userland_io[HERAIX_USERLAND_OUTPUT_OFFSET + index] == 0;
}

static int process_name_matches(uint64_t packed, const char *name)
{
    uint64_t expected = 0;
    return heraix_process_name_pack(name, &expected) == RPC_OK &&
           packed == expected;
}

static void req(uint32_t service, uint32_t opcode, uint64_t arg0, uint64_t arg1)
{
    ++seq;
    int32_t status = RPC_BAD_REQUEST;
    if (service == SVC_SYSTEM && opcode == OP_GET_INFO) {
        status = heraix_system_get_info(rpc, seq);
    } else if (service == SVC_MEMORY && opcode == OP_ALLOC) {
        status = heraix_memory_alloc(rpc, seq);
    } else if (service == SVC_RESOURCE && opcode == OP_GET_RESOURCE) {
        status = heraix_resource_get_info(rpc, seq);
    } else if (service == SVC_DEVICE && opcode == OP_DEVICE_LOOKUP) {
        status = heraix_device_lookup(rpc, seq, (uint16_t)arg0, (uint16_t)arg1);
    } else if (service == SVC_STORAGE && opcode == OP_STORAGE_INFO) {
        status = heraix_storage_info(rpc, seq);
    } else if (service == SVC_STORAGE && opcode == OP_BLOCK_READ) {
        status = heraix_storage_read(rpc, seq, arg0, arg1, 0);
    } else if (service == SVC_STORAGE && opcode == OP_BLOCK_WRITE) {
        status = heraix_storage_write(rpc, seq, arg0, arg1, 0);
    } else if (service == SVC_VFS &&
               (opcode == OP_VFS_READDIR || opcode == OP_VFS_STAT ||
                opcode == OP_VFS_MKDIR || opcode == OP_VFS_CREATE ||
                opcode == OP_VFS_UNLINK || opcode == OP_VFS_RENAME)) {
        status = heraix_fs_path_request(rpc, seq, opcode);
    } else if (service == SVC_FILE && opcode == OP_FILE_OPEN) {
        status = heraix_file_open(rpc, vfs_io, seq,
                                  "/tmp/home/fsvc", (uint32_t)arg0);
    } else if (service == SVC_FILE &&
                (opcode == OP_FILE_CLOSE || opcode == OP_FILE_READ ||
                 opcode == OP_FILE_WRITE || opcode == OP_FILE_SEEK)) {
        status = heraix_file_handle_request(rpc, seq, opcode, arg0, arg1);
    } else if (service == SVC_PROCESS && opcode == OP_PROCESS_CREATE) {
        status = heraix_process_create_named(rpc, seq, (uint32_t)arg0,
                                             (uint32_t)arg1, "worker");
    } else {
        status = heraix_rpc_prepare(rpc, seq, service, opcode, arg0, arg1, 0);
    }
    if (status != RPC_OK) {
        microkit_dbg_puts("API_REQUEST_BUILD_FAIL\n");
    }
}

void init(void)
{
    microkit_dbg_puts("HERAIX_ROOT_OK\n");
    req(SVC_SYSTEM, OP_GET_INFO, 1, 0);
    microkit_notify(CH_SYSTEM);
}

void notified(microkit_channel ch)
{
    if (ch == CH_SYSTEM) {
        if (rpc->status != RPC_OK) {
            microkit_dbg_puts("SYSTEM_API_FAIL\n");
            return;
        }
        if (rpc->opcode == OP_GET_HEALTH) {
            if (rpc->value0 != 11 || rpc->value1 != 1) {
                microkit_dbg_puts("SYSTEM_HEALTH_FAIL\n");
                return;
            }
            microkit_dbg_puts("SYSTEM_HEALTH_OK\n");
            req(SVC_MEMORY, OP_ALLOC, 1, 0);
            microkit_notify(CH_MEMORY);
            return;
        }
        microkit_dbg_puts("SYSTEM_SERVICE_OK\n");
        microkit_dbg_puts("SYSTEM_API_OK\n");
        req(SVC_SYSTEM, OP_GET_HEALTH, 1, 0);
        microkit_notify(CH_SYSTEM);
        return;
    }

    if (ch == CH_MEMORY) {
        if (rpc->status != RPC_OK) {
            microkit_dbg_puts("MEMORY_ALLOC_FAIL\n");
            return;
        }

        if (rpc->opcode == OP_FREE) {
            if (rpc->status != RPC_OK) {
                microkit_dbg_puts("MEMORY_FREE_FAIL\n");
                return;
            }
            microkit_dbg_puts("MEMORY_FREE_OK\n");
            req(SVC_RESOURCE, OP_GET_RESOURCE, 1, 0);
            microkit_notify(CH_RESOURCE);
            return;
        }

        uint64_t off = rpc->value0;
        if (off >= HERAIX_POOL_SIZE) {
            microkit_dbg_puts("MEMORY_OFFSET_FAIL\n");
            return;
        }

        pool[off + 0] = 'M';
        pool[off + 1] = 'M';
        pool[off + 2] = 'K';
        pool[off + 3] = 'A';

        if (pool[off] != 'M' || pool[off+1] != 'M' ||
            pool[off+2] != 'K' || pool[off+3] != 'A') {
            microkit_dbg_puts("MEMORY_TEST_FAIL\n");
            return;
        }

        microkit_dbg_puts("MEMORY_SERVICE_OK\n");
        microkit_dbg_puts("MEMORY_ALLOC_OK\n");
        allocated_memory_offset = off;
        req(SVC_MEMORY, OP_FREE, allocated_memory_offset, 1);
        microkit_notify(CH_MEMORY);
        return;
    }

    if (ch == CH_RESOURCE) {
        if (rpc->status != RPC_OK) {
            microkit_dbg_puts("RESOURCE_API_FAIL\n");
            return;
        }
        microkit_dbg_puts("RESOURCE_SERVICE_OK\n");
        microkit_dbg_puts("RESOURCE_API_OK\n");
        req(SVC_DEVICE, OP_DEVICE_LOOKUP, 0x8086, 0x7000);
        microkit_notify(CH_DEVICE);
        return;
    }

    if (ch == CH_DEVICE) {
        if (rpc->opcode == OP_DEVICE_LOOKUP) {
            if (rpc->status != RPC_OK ||
                rpc->value0 != 0x8086 ||
                rpc->value1 != 0x7000 ||
                rpc->value2 != HERAIX_DEVICE_OWNER_DEVICE_SERVICE ||
                rpc->value3 != 0x0008) {
                microkit_dbg_puts("DEVICE_API_FAIL\n");
                return;
            }
            microkit_dbg_puts("DEVICE_SERVICE_OK\n");
            microkit_dbg_puts("DEVICE_DISCOVERY_OK\n");
            microkit_dbg_puts("DEVICE_REGISTRATION_OK\n");
            microkit_dbg_puts("DEVICE_API_OK\n");
            microkit_dbg_puts("DEVICE_ACCESS_OK\n");
            req(SVC_DEVICE, 0xffffffffu, 0, 0);
            microkit_notify(CH_DEVICE);
            return;
        }

        if (rpc->status != RPC_BAD_REQUEST) {
            microkit_dbg_puts("DEVICE_BAD_REQUEST_FAIL\n");
            return;
        }
        microkit_dbg_puts("DEVICE_BAD_REQUEST_REJECTED\n");
        req(SVC_STORAGE, OP_STORAGE_INFO, 0, 0);
        microkit_notify(CH_STORAGE);
        return;
    }

    if (ch == CH_STORAGE) {
        if (rpc->opcode == OP_STORAGE_INFO) {
            if (rpc->status != RPC_OK ||
                rpc->value0 != HERAIX_BLOCK_SIZE ||
                rpc->value1 != HERAIX_BLOCK_COUNT ||
                rpc->value2 != HERAIX_STORAGE_OWNER_STORAGE_SERVICE) {
                microkit_dbg_puts("STORAGE_INFO_FAIL\n");
                return;
            }
            microkit_dbg_puts("STORAGE_SERVICE_OK\n");
            microkit_dbg_puts("STORAGE_API_OK\n");
            microkit_dbg_puts("STORAGE_BLOCK_INFO_OK\n");
            storage_io[0] = 'H';
            storage_io[1] = 'R';
            storage_io[2] = 'X';
            storage_io[3] = 'S';
            req(SVC_STORAGE, OP_BLOCK_WRITE, 2, 4);
            microkit_notify(CH_STORAGE);
            return;
        }

        if (rpc->opcode == OP_BLOCK_WRITE) {
            if (rpc->status != RPC_OK) {
                microkit_dbg_puts("STORAGE_BLOCK_WRITE_FAIL\n");
                return;
            }
            microkit_dbg_puts("STORAGE_BLOCK_WRITE_OK\n");
            storage_io[0] = 0;
            storage_io[1] = 0;
            storage_io[2] = 0;
            storage_io[3] = 0;
            req(SVC_STORAGE, OP_BLOCK_READ, 2, 4);
            microkit_notify(CH_STORAGE);
            return;
        }

        if (rpc->opcode == OP_BLOCK_READ && rpc->status == RPC_OK) {
            if (storage_io[0] != 'H' ||
                storage_io[1] != 'R' || storage_io[2] != 'X' ||
                storage_io[3] != 'S') {
                microkit_dbg_puts("STORAGE_BLOCK_READ_FAIL\n");
                return;
            }
            microkit_dbg_puts("STORAGE_BLOCK_READ_OK\n");
            req(SVC_STORAGE, OP_BLOCK_READ, HERAIX_BLOCK_COUNT, 4);
            microkit_notify(CH_STORAGE);
            return;
        }

        if (rpc->status != RPC_INVALID_RANGE) {
            microkit_dbg_puts("STORAGE_BAD_RANGE_FAIL\n");
            return;
        }
        microkit_dbg_puts("STORAGE_BAD_RANGE_REJECTED\n");
        req(SVC_VFS, OP_VFS_READDIR, 0, 0);
        set_vfs_path("/system");
        microkit_notify(CH_VFS);
        return;
    }

    if (ch == CH_VFS) {
        if (vfs_acl_test_state == 1 && rpc->opcode == OP_VFS_READDIR &&
            rpc->status == RPC_OK) {
            microkit_dbg_puts("VFS_ACL_READ_ALLOW_OK\n");
            vfs_acl_test_state = 2;
            req(SVC_VFS, OP_VFS_MKDIR, 0, 0);
            set_vfs_path("/tmp/acl-denied");
            microkit_notify(CH_VFS);
            return;
        }
        if (vfs_acl_test_state == 2 && rpc->opcode == OP_VFS_MKDIR &&
            rpc->status == RPC_PERMISSION) {
            microkit_dbg_puts("VFS_ACL_WRITE_DENY_OK\n");
            microkit_dbg_puts("VFS_ACL_ENFORCEMENT_OK\n");
            vfs_acl_test_state = 3;
            rpc->reserved = HERAIX_TOKEN_ROOT;
            microkit_dbg_puts("CORE_OK\n");
            return;
        }
        if (ramfs_test_state != 0) {
            if (ramfs_test_state == 1 && rpc->opcode == OP_VFS_MKDIR &&
                rpc->status == RPC_OK) {
                microkit_dbg_puts("RAMFS_MKDIR_OK\n");
                ramfs_test_state = 2;
                set_vfs_path("/tmp/home/note");
                req(SVC_VFS, OP_VFS_CREATE, 0, 0);
                microkit_notify(CH_VFS);
                return;
            }
            if (ramfs_test_state == 2 && rpc->opcode == OP_VFS_CREATE &&
                rpc->status == RPC_OK) {
                microkit_dbg_puts("RAMFS_CREATE_OK\n");
                ramfs_test_state = 3;
                set_vfs_path("/tmp/home/note");
                req(SVC_VFS, OP_VFS_OPEN, 3, 0);
                microkit_notify(CH_VFS);
                return;
            }
            if (ramfs_test_state == 3 && rpc->opcode == OP_VFS_OPEN &&
                rpc->status == RPC_OK && rpc->value0 != 0) {
                vfs_handle = rpc->value0;
                vfs_io[HERAIX_VFS_DATA_OFFSET] = 'R';
                vfs_io[HERAIX_VFS_DATA_OFFSET + 1] = 'A';
                vfs_io[HERAIX_VFS_DATA_OFFSET + 2] = 'M';
                vfs_io[HERAIX_VFS_DATA_OFFSET + 3] = '!';
                ramfs_test_state = 4;
                req(SVC_VFS, OP_VFS_WRITE, vfs_handle, 4);
                microkit_notify(CH_VFS);
                return;
            }
            if (ramfs_test_state == 4 && rpc->opcode == OP_VFS_WRITE &&
                rpc->status == RPC_OK && rpc->value0 == 4) {
                microkit_dbg_puts("RAMFS_WRITE_OK\n");
                ramfs_test_state = 5;
                req(SVC_VFS, OP_VFS_SEEK, vfs_handle, 0);
                microkit_notify(CH_VFS);
                return;
            }
            if (ramfs_test_state == 5 && rpc->opcode == OP_VFS_SEEK &&
                rpc->status == RPC_OK && rpc->value0 == 0) {
                ramfs_test_state = 6;
                req(SVC_VFS, OP_VFS_READ, vfs_handle, 4);
                microkit_notify(CH_VFS);
                return;
            }
            if (ramfs_test_state == 6 && rpc->opcode == OP_VFS_READ &&
                rpc->status == RPC_OK && rpc->value0 == 4 &&
                vfs_io[HERAIX_VFS_DATA_OFFSET] == 'R' &&
                vfs_io[HERAIX_VFS_DATA_OFFSET + 1] == 'A' &&
                vfs_io[HERAIX_VFS_DATA_OFFSET + 2] == 'M' &&
                vfs_io[HERAIX_VFS_DATA_OFFSET + 3] == '!') {
                microkit_dbg_puts("RAMFS_READ_OK\n");
                ramfs_test_state = 7;
                set_vfs_path("/tmp/home/note");
                req(SVC_VFS, OP_VFS_STAT, 0, 0);
                microkit_notify(CH_VFS);
                return;
            }
            if (ramfs_test_state == 7 && rpc->opcode == OP_VFS_STAT &&
                rpc->status == RPC_OK && rpc->value0 == 4 && rpc->value1 == 1) {
                microkit_dbg_puts("RAMFS_STAT_OK\n");
                ramfs_test_state = 8;
                req(SVC_VFS, OP_VFS_CLOSE, vfs_handle, 0);
                microkit_notify(CH_VFS);
                return;
            }
            if (ramfs_test_state == 8 && rpc->opcode == OP_VFS_CLOSE &&
                rpc->status == RPC_OK) {
                ramfs_test_state = 9;
                set_vfs_path("/tmp/home");
                req(SVC_VFS, OP_VFS_READDIR, 0, 0);
                microkit_notify(CH_VFS);
                return;
            }
            if (ramfs_test_state == 9 && rpc->opcode == OP_VFS_READDIR &&
                rpc->status == RPC_OK && rpc->value0 == 1 &&
                vfs_io[HERAIX_VFS_PATH_OFFSET] == 'n' &&
                vfs_io[HERAIX_VFS_PATH_OFFSET + 1] == 'o' &&
                vfs_io[HERAIX_VFS_PATH_OFFSET + 2] == 't' &&
                vfs_io[HERAIX_VFS_PATH_OFFSET + 3] == 'e') {
                microkit_dbg_puts("RAMFS_READDIR_OK\n");
                ramfs_test_state = 10;
                set_vfs_path("/tmp/home/note");
                set_vfs_string(HERAIX_VFS_DATA_OFFSET, "/tmp/home/renamed");
                req(SVC_VFS, OP_VFS_RENAME, 0, 0);
                microkit_notify(CH_VFS);
                return;
            }
            if (ramfs_test_state == 10 && rpc->opcode == OP_VFS_RENAME &&
                rpc->status == RPC_OK) {
                microkit_dbg_puts("RAMFS_RENAME_OK\n");
                ramfs_test_state = 11;
                set_vfs_path("/tmp/home/renamed");
                req(SVC_VFS, OP_VFS_STAT, 0, 0);
                microkit_notify(CH_VFS);
                return;
            }
            if (ramfs_test_state == 11 && rpc->opcode == OP_VFS_STAT &&
                rpc->status == RPC_OK && rpc->value0 == 4 && rpc->value1 == 1) {
                ramfs_test_state = 12;
                set_vfs_path("/tmp/home/renamed");
                req(SVC_VFS, OP_VFS_UNLINK, 0, 0);
                microkit_notify(CH_VFS);
                return;
            }
            if (ramfs_test_state == 12 && rpc->opcode == OP_VFS_UNLINK &&
                rpc->status == RPC_OK) {
                ramfs_test_state = 13;
                set_vfs_path("/tmp/home/renamed");
                req(SVC_VFS, OP_VFS_STAT, 0, 0);
                microkit_notify(CH_VFS);
                return;
            }
            if (ramfs_test_state == 13 && rpc->opcode == OP_VFS_STAT &&
                rpc->status == RPC_NOT_FOUND) {
                microkit_dbg_puts("RAMFS_UNLINK_OK\n");
                microkit_dbg_puts("RAMFS_OK\n");
                file_test_state = 1;
                set_vfs_path("/tmp/home/fsvc");
                req(SVC_FILE, OP_FILE_CREATE, 0, 0);
                microkit_notify(CH_FILE);
                return;
            }
            microkit_dbg_puts("RAMFS_TEST_FAIL\n");
            return;
        }

        if (rpc->opcode == OP_VFS_READDIR) {
            if (rpc->status != RPC_OK || rpc->value0 != 1 ||
                vfs_io[HERAIX_VFS_PATH_OFFSET] != 'b' ||
                vfs_io[HERAIX_VFS_PATH_OFFSET + 1] != 'o' ||
                vfs_io[HERAIX_VFS_PATH_OFFSET + 2] != 'o' ||
                vfs_io[HERAIX_VFS_PATH_OFFSET + 3] != 't') {
                microkit_dbg_puts("VFS_READDIR_FAIL\n");
                return;
            }
            microkit_dbg_puts("VFS_SERVICE_OK\n");
            microkit_dbg_puts("VFS_MOUNT_OK\n");
            microkit_dbg_puts("VFS_READDIR_OK\n");
            set_vfs_path("/system/boot");
            req(SVC_VFS, OP_VFS_OPEN, 3, 0);
            microkit_notify(CH_VFS);
            return;
        }

        if (rpc->opcode == OP_VFS_OPEN) {
            if (rpc->status != RPC_OK || rpc->value0 == 0) {
                microkit_dbg_puts("VFS_OPEN_FAIL\n");
                return;
            }
            vfs_handle = rpc->value0;
            microkit_dbg_puts("VFS_OPEN_OK\n");
            vfs_io[HERAIX_VFS_DATA_OFFSET] = 'V';
            vfs_io[HERAIX_VFS_DATA_OFFSET + 1] = 'F';
            vfs_io[HERAIX_VFS_DATA_OFFSET + 2] = 'S';
            vfs_io[HERAIX_VFS_DATA_OFFSET + 3] = '!';
            req(SVC_VFS, OP_VFS_WRITE, vfs_handle, 4);
            microkit_notify(CH_VFS);
            return;
        }

        if (rpc->opcode == OP_VFS_WRITE) {
            if (rpc->status != RPC_OK || rpc->value0 != 4) {
                microkit_dbg_puts("VFS_WRITE_FAIL\n");
                return;
            }
            microkit_dbg_puts("VFS_WRITE_OK\n");
            req(SVC_VFS, OP_VFS_SEEK, vfs_handle, 0);
            microkit_notify(CH_VFS);
            return;
        }

        if (rpc->opcode == OP_VFS_SEEK) {
            if (rpc->status != RPC_OK || rpc->value0 != 0) {
                microkit_dbg_puts("VFS_SEEK_FAIL\n");
                return;
            }
            microkit_dbg_puts("VFS_SEEK_OK\n");
            req(SVC_VFS, OP_VFS_READ, vfs_handle, 4);
            microkit_notify(CH_VFS);
            return;
        }

        if (rpc->opcode == OP_VFS_READ && rpc->status == RPC_OK) {
            if (rpc->value0 != 4 ||
                vfs_io[HERAIX_VFS_DATA_OFFSET] != 'V' ||
                vfs_io[HERAIX_VFS_DATA_OFFSET + 1] != 'F' ||
                vfs_io[HERAIX_VFS_DATA_OFFSET + 2] != 'S' ||
                vfs_io[HERAIX_VFS_DATA_OFFSET + 3] != '!') {
                microkit_dbg_puts("VFS_READ_FAIL\n");
                return;
            }
            microkit_dbg_puts("VFS_READ_OK\n");
            set_vfs_path("/system/boot");
            req(SVC_VFS, OP_VFS_STAT, 0, 0);
            microkit_notify(CH_VFS);
            return;
        }

        if (rpc->opcode == OP_VFS_STAT) {
            if (rpc->status != RPC_OK || rpc->value0 != HERAIX_BLOCK_SIZE ||
                rpc->value1 != 1) {
                microkit_dbg_puts("VFS_STAT_FAIL\n");
                return;
            }
            microkit_dbg_puts("VFS_STAT_OK\n");
            req(SVC_VFS, OP_VFS_CLOSE, vfs_handle, 0);
            microkit_notify(CH_VFS);
            return;
        }

        if (rpc->opcode == OP_VFS_CLOSE && rpc->status == RPC_OK) {
            microkit_dbg_puts("VFS_CLOSE_OK\n");
            req(SVC_VFS, OP_VFS_CLOSE, vfs_handle, 0);
            microkit_notify(CH_VFS);
            return;
        }

        if (rpc->status != RPC_INVALID_HANDLE) {
            microkit_dbg_puts("VFS_BAD_HANDLE_FAIL\n");
            return;
        }
        microkit_dbg_puts("VFS_BAD_HANDLE_REJECTED\n");
        microkit_dbg_puts("VFS_OK\n");
        ramfs_test_state = 1;
        set_vfs_path("/tmp/home");
        req(SVC_VFS, OP_VFS_MKDIR, 0, 0);
        microkit_notify(CH_VFS);
    }

    if (ch == CH_FILE) {
        if (file_test_state == 1 && rpc->opcode == OP_FILE_CREATE &&
            rpc->status == RPC_OK) {
            microkit_dbg_puts("FILE_SERVICE_OK\n");
            microkit_dbg_puts("FILE_CREATE_OK\n");
            file_test_state = 2;
            set_vfs_path("/tmp/home/fsvc");
            req(SVC_FILE, OP_FILE_OPEN, 3, 0);
            microkit_notify(CH_FILE);
            return;
        }
        if (file_test_state == 2 && rpc->opcode == OP_FILE_OPEN &&
            rpc->status == RPC_OK && rpc->value0 != 0) {
            file_descriptor = rpc->value0;
            microkit_dbg_puts("FILE_OPEN_OK\n");
            vfs_io[HERAIX_VFS_DATA_OFFSET] = 'F';
            vfs_io[HERAIX_VFS_DATA_OFFSET + 1] = 'S';
            vfs_io[HERAIX_VFS_DATA_OFFSET + 2] = 'V';
            vfs_io[HERAIX_VFS_DATA_OFFSET + 3] = 'C';
            file_test_state = 3;
            req(SVC_FILE, OP_FILE_WRITE, file_descriptor, 4);
            microkit_notify(CH_FILE);
            return;
        }
        if (file_test_state == 3 && rpc->opcode == OP_FILE_WRITE &&
            rpc->status == RPC_OK && rpc->value0 == 4) {
            microkit_dbg_puts("FILE_WRITE_OK\n");
            file_test_state = 4;
            req(SVC_FILE, OP_FILE_SEEK, file_descriptor, 0);
            microkit_notify(CH_FILE);
            return;
        }
        if (file_test_state == 4 && rpc->opcode == OP_FILE_SEEK &&
            rpc->status == RPC_OK && rpc->value0 == 0) {
            microkit_dbg_puts("FILE_SEEK_OK\n");
            file_test_state = 5;
            req(SVC_FILE, OP_FILE_READ, file_descriptor, 4);
            microkit_notify(CH_FILE);
            return;
        }
        if (file_test_state == 5 && rpc->opcode == OP_FILE_READ &&
            rpc->status == RPC_OK && rpc->value0 == 4 &&
            vfs_io[HERAIX_VFS_DATA_OFFSET] == 'F' &&
            vfs_io[HERAIX_VFS_DATA_OFFSET + 1] == 'S' &&
            vfs_io[HERAIX_VFS_DATA_OFFSET + 2] == 'V' &&
            vfs_io[HERAIX_VFS_DATA_OFFSET + 3] == 'C') {
            microkit_dbg_puts("FILE_READ_OK\n");
            file_test_state = 6;
            set_vfs_path("/tmp/home/fsvc");
            req(SVC_FILE, OP_FILE_STAT, 0, 0);
            microkit_notify(CH_FILE);
            return;
        }
        if (file_test_state == 6 && rpc->opcode == OP_FILE_STAT &&
            rpc->status == RPC_OK && rpc->value0 == 4 && rpc->value1 == 1) {
            microkit_dbg_puts("FILE_STAT_OK\n");
            file_test_state = 7;
            req(SVC_FILE, OP_FILE_CLOSE, file_descriptor, 0);
            microkit_notify(CH_FILE);
            return;
        }
        if (file_test_state == 7 && rpc->opcode == OP_FILE_CLOSE &&
            rpc->status == RPC_OK) {
            microkit_dbg_puts("FILE_CLOSE_OK\n");
            stale_file_descriptor = file_descriptor;
            file_test_state = 8;
            set_vfs_path("/tmp/home/fsvc");
            req(SVC_FILE, OP_FILE_OPEN, 1, 0);
            microkit_notify(CH_FILE);
            return;
        }
        if (file_test_state == 8 && rpc->opcode == OP_FILE_OPEN &&
            rpc->status == RPC_OK && rpc->value0 != 0 &&
            rpc->value0 != stale_file_descriptor) {
            file_descriptor = rpc->value0;
            file_test_state = 9;
            req(SVC_FILE, OP_FILE_READ, stale_file_descriptor, 1);
            microkit_notify(CH_FILE);
            return;
        }
        if (file_test_state == 9 && rpc->status == RPC_INVALID_HANDLE) {
            microkit_dbg_puts("FILE_BAD_HANDLE_REJECTED\n");
            microkit_dbg_puts("FILE_STALE_HANDLE_REJECTED\n");
            file_test_state = 10;
            req(SVC_FILE, OP_FILE_CLOSE, file_descriptor, 0);
            microkit_notify(CH_FILE);
            return;
        }
        if (file_test_state == 10 && rpc->opcode == OP_FILE_CLOSE &&
            rpc->status == RPC_OK) {
            file_test_state = 11;
            set_vfs_path("/tmp/home");
            req(SVC_FILE, OP_FILE_READDIR, 0, 0);
            microkit_notify(CH_FILE);
            return;
        }
        if (file_test_state == 11 && rpc->opcode == OP_FILE_READDIR &&
            rpc->status == RPC_OK && rpc->value0 == 1 &&
            vfs_io[HERAIX_VFS_PATH_OFFSET] == 'f' &&
            vfs_io[HERAIX_VFS_PATH_OFFSET + 1] == 's' &&
            vfs_io[HERAIX_VFS_PATH_OFFSET + 2] == 'v' &&
            vfs_io[HERAIX_VFS_PATH_OFFSET + 3] == 'c') {
            microkit_dbg_puts("FILE_READDIR_OK\n");
            file_test_state = 12;
            set_vfs_path("/tmp/home/fsvc");
            set_vfs_string(HERAIX_VFS_DATA_OFFSET, "/tmp/home/renamed-fsvc");
            req(SVC_FILE, OP_FILE_RENAME, 0, 0);
            microkit_notify(CH_FILE);
            return;
        }
        if (file_test_state == 12 && rpc->opcode == OP_FILE_RENAME &&
            rpc->status == RPC_OK) {
            microkit_dbg_puts("FILE_RENAME_OK\n");
            file_test_state = 13;
            set_vfs_path("/tmp/home/renamed-fsvc");
            req(SVC_FILE, OP_FILE_STAT, 0, 0);
            microkit_notify(CH_FILE);
            return;
        }
        if (file_test_state == 13 && rpc->opcode == OP_FILE_STAT &&
            rpc->status == RPC_OK && rpc->value0 == 4 && rpc->value1 == 1) {
            file_test_state = 14;
            set_vfs_path("/tmp/home/renamed-fsvc");
            req(SVC_FILE, OP_FILE_UNLINK, 0, 0);
            microkit_notify(CH_FILE);
            return;
        }
        if (file_test_state == 14 && rpc->opcode == OP_FILE_UNLINK &&
            rpc->status == RPC_OK) {
            file_test_state = 15;
            set_vfs_path("/tmp/home/renamed-fsvc");
            req(SVC_FILE, OP_FILE_STAT, 0, 0);
            microkit_notify(CH_FILE);
            return;
        }
        if (file_test_state == 15 && rpc->opcode == OP_FILE_STAT &&
            rpc->status == RPC_NOT_FOUND) {
            microkit_dbg_puts("FILE_UNLINK_OK\n");
            microkit_dbg_puts("FILE_API_OK\n");
            microkit_dbg_puts("FILE_OK\n");
            microkit_dbg_puts("VFS_OK\n");
            file_test_state = 16;
            set_vfs_path("/tmp/home/fsvc");
            req(SVC_FILE, OP_FILE_STAT, 0, 0);
            rpc->version = HERAIX_ABI_VERSION + 1;
            microkit_notify(CH_FILE);
            return;
        }
        if (file_test_state == 16 && rpc->status == RPC_BAD_REQUEST) {
            microkit_dbg_puts("ABI_INVALID_REQUEST_REJECTED\n");
            file_test_state = 17;
            req(SVC_FILE, OP_FILE_STAT, 0, 0);
            rpc->size -= 1;
            microkit_notify(CH_FILE);
            return;
        }
        if (file_test_state == 17 && rpc->status == RPC_BAD_REQUEST) {
            microkit_dbg_puts("ABI_INVALID_SIZE_REJECTED\n");
            file_test_state = 18;
            req(SVC_FILE, OP_FILE_STAT, 0, 0);
            rpc->flags = 1;
            microkit_notify(CH_FILE);
            return;
        }
        if (file_test_state == 18 && rpc->status == RPC_BAD_REQUEST) {
            microkit_dbg_puts("ABI_INVALID_FLAGS_REJECTED\n");
            userland_test_state = 1;
            run_shell_command("help");
            return;
        }
        microkit_dbg_puts("FILE_TEST_FAIL\n");
    }

    if (ch == CH_USERLAND) {
        if (rpc->service != SVC_USERLAND ||
            rpc->opcode != OP_USERLAND_EXEC || rpc->status != RPC_OK) {
            microkit_dbg_puts("USERLAND_TEST_FAIL\n");
            return;
        }
        if (userland_test_state == 1 &&
            userland_io[HERAIX_USERLAND_OUTPUT_OFFSET] == 'h') {
            microkit_dbg_puts("USERLAND_SERVICE_OK\n");
            microkit_dbg_puts("USERLAND_HELP_OK\n");
            userland_test_state = 2;
            run_shell_command("mkdir /tmp/shell");
        } else if (userland_test_state == 2) {
            microkit_dbg_puts("USERLAND_MKDIR_OK\n");
            userland_test_state = 3;
            run_shell_command("write /tmp/shell/note hello");
        } else if (userland_test_state == 3 &&
                   userland_output_matches("written")) {
            microkit_dbg_puts("USERLAND_WRITE_OK\n");
            userland_test_state = 4;
            run_shell_command("cat /tmp/shell/note");
        } else if (userland_test_state == 4 &&
                   userland_output_matches("hello")) {
            microkit_dbg_puts("USERLAND_CAT_OK\n");
            userland_test_state = 5;
            run_shell_command("ls /tmp/shell");
        } else if (userland_test_state == 5 &&
                   userland_output_matches("note")) {
            microkit_dbg_puts("USERLAND_LS_OK\n");
            userland_test_state = 6;
            run_shell_command("mv /tmp/shell/note /tmp/shell/renamed");
        } else if (userland_test_state == 6) {
            microkit_dbg_puts("USERLAND_MV_OK\n");
            userland_test_state = 7;
            run_shell_command("rm /tmp/shell/renamed");
        } else if (userland_test_state == 7) {
            microkit_dbg_puts("USERLAND_RM_OK\n");
            userland_test_state = 8;
            run_shell_command("cd /tmp/shell");
        } else if (userland_test_state == 8) {
            microkit_dbg_puts("USERLAND_CD_OK\n");
            userland_test_state = 9;
            run_shell_command("pwd");
        } else if (userland_test_state == 9 &&
                   userland_output_matches("/tmp/shell")) {
            microkit_dbg_puts("USERLAND_PWD_OK\n");
            userland_test_state = 10;
            run_shell_command("mount");
        } else if (userland_test_state == 10 &&
                   userland_output_matches("/\n/tmp")) {
            microkit_dbg_puts("USERLAND_MOUNT_OK\n");
            userland_test_state = 11;
            run_shell_command("info");
        } else if (userland_test_state == 11 &&
                   userland_output_matches("system ready")) {
            microkit_dbg_puts("USERLAND_INFO_OK\n");
            userland_test_state = 12;
            run_shell_command("mem");
        } else if (userland_test_state == 12 &&
                   userland_output_matches("memory allocated")) {
            microkit_dbg_puts("USERLAND_MEM_OK\n");
            userland_test_state = 13;
            run_shell_command("resource");
        } else if (userland_test_state == 13 &&
                   userland_output_matches("resources available")) {
            microkit_dbg_puts("USERLAND_RESOURCE_OK\n");
            userland_test_state = 14;
            run_shell_command("device");
        } else if (userland_test_state == 14 &&
                   userland_output_matches("8086:7000")) {
            microkit_dbg_puts("USERLAND_DEVICE_OK\n");
            microkit_dbg_puts("USERLAND_OK\n");
            process_test_state = 1;
            req(SVC_PROCESS, OP_PROCESS_CREATE, 1, 0);
            microkit_notify(CH_PROCESS);
        } else {
            microkit_dbg_puts("USERLAND_COMMAND_FAIL\n");
        }
    }

    if (ch == CH_PROCESS) {
        if (rpc->status != RPC_OK) { microkit_dbg_puts("PROCESS_TEST_FAIL\n"); return; }
        if (process_test_state == 1 && rpc->opcode == OP_PROCESS_CREATE &&
            rpc->value0 > 1 && rpc->value1 > 1) {
            managed_pid = (uint32_t)rpc->value0;
            managed_tid = (uint32_t)rpc->value1;
            microkit_dbg_puts("PROCESS_SERVICE_OK\n");
            microkit_dbg_puts("PROCESS_CREATE_OK\n");
            process_test_state = 2;
            req(SVC_PROCESS, OP_PROCESS_ENUMERATE, 1, 0);
            microkit_notify(CH_PROCESS);
        } else if (process_test_state == 2 &&
                   rpc->opcode == OP_PROCESS_ENUMERATE &&
                   rpc->value0 == managed_pid &&
                   rpc->value1 == HERAIX_PROCESS_STATE_RUNNING &&
                   rpc->value2 == 1 && rpc->value3 == 0 &&
                   process_name_matches(rpc->arg2, "worker")) {
            microkit_dbg_puts("PROCESS_ENUMERATION_OK\n");
            process_test_state = 3;
            req(SVC_PROCESS, OP_PROCESS_EVENT_QUERY, 0, 0);
            microkit_notify(CH_PROCESS);
        } else if (process_test_state == 3 &&
                   rpc->opcode == OP_PROCESS_EVENT_QUERY &&
                   rpc->value1 == HERAIX_PROCESS_EVENT_CREATED &&
                   rpc->value2 == managed_pid && rpc->value3 == managed_tid &&
                   rpc->arg0 == HERAIX_PROCESS_STATE_RUNNING) {
            microkit_dbg_puts("PROCESS_EVENT_QUERY_OK\n");
            process_test_state = 4;
            req(SVC_PROCESS, OP_THREAD_CREATE, managed_pid, 0);
            microkit_notify(CH_PROCESS);
        } else if (process_test_state == 4 &&
                   rpc->opcode == OP_THREAD_CREATE &&
                   rpc->value0 > managed_tid) {
            managed_thread = (uint32_t)rpc->value0;
            microkit_dbg_puts("THREAD_CREATE_OK\n");
            process_test_state = 5;
            req(SVC_PROCESS, OP_THREAD_QUERY, managed_thread, 0);
            microkit_notify(CH_PROCESS);
        } else if (process_test_state == 5 && rpc->opcode == OP_THREAD_QUERY &&
                   rpc->value0 == HERAIX_PROCESS_STATE_RUNNING &&
                   rpc->value1 == managed_pid && rpc->used_blocks == 1) {
            microkit_dbg_puts("THREAD_QUERY_OK\n");
            process_test_state = 6;
            req(SVC_PROCESS, OP_PROCESS_QUERY, managed_pid, 0);
            microkit_notify(CH_PROCESS);
        } else if (process_test_state == 6 && rpc->opcode == OP_PROCESS_QUERY &&
                   rpc->value0 == HERAIX_PROCESS_STATE_RUNNING &&
                   rpc->value1 == 2 && rpc->value2 == 1 && rpc->value3 == 0 &&
                   rpc->used_blocks == 1 && rpc->reserved == 1) {
            microkit_dbg_puts("PROCESS_QUERY_OK\n");
            process_test_state = 7;
            req(SVC_PROCESS, OP_THREAD_EXIT, managed_thread, 0);
            microkit_notify(CH_PROCESS);
        } else if (process_test_state == 7 && rpc->opcode == OP_THREAD_EXIT) {
            microkit_dbg_puts("THREAD_EXIT_OK\n");
            process_test_state = 8;
            req(SVC_PROCESS, OP_PROCESS_EXIT, managed_pid, 0);
            microkit_notify(CH_PROCESS);
        } else if (process_test_state == 8 && rpc->opcode == OP_PROCESS_EXIT) {
            microkit_dbg_puts("PROCESS_EXIT_OK\n");
            process_test_state = 9;
            req(SVC_SECURITY, OP_USER_CREATE, 100, 0);
            microkit_notify(CH_SECURITY);
        } else { microkit_dbg_puts("PROCESS_TEST_FAIL\n"); }
    }

    if (ch == CH_SECURITY) {
        if (security_test_state == 0 && rpc->opcode == OP_USER_CREATE && rpc->status == RPC_OK) {
            microkit_dbg_puts("SECURITY_SERVICE_OK\n"); microkit_dbg_puts("USER_CREATE_OK\n"); security_test_state=1;
            req(SVC_SECURITY, OP_GROUP_CREATE, 100, 0); microkit_notify(CH_SECURITY);
        } else if (security_test_state == 1 && rpc->opcode == OP_GROUP_CREATE && rpc->status == RPC_OK) {
            microkit_dbg_puts("GROUP_CREATE_OK\n"); security_test_state=2;
            req(SVC_SECURITY, OP_GROUP_ADD_MEMBER, 100, 100); microkit_notify(CH_SECURITY);
        } else if (security_test_state == 2 && rpc->opcode == OP_GROUP_ADD_MEMBER && rpc->status == RPC_OK) {
            microkit_dbg_puts("GROUP_MEMBER_OK\n"); security_test_state=3;
            req(SVC_SECURITY, OP_TOKEN_ISSUE, 100, 0); microkit_notify(CH_SECURITY);
        } else if (security_test_state == 3 && rpc->opcode == OP_TOKEN_ISSUE && rpc->status == RPC_OK) {
            security_token=(uint32_t)rpc->value0; microkit_dbg_puts("TOKEN_ISSUE_OK\n"); security_test_state=4;
            req(SVC_SECURITY, OP_ACL_SET, 0x1000, 100); rpc->arg2=HERAIX_RIGHT_READ; microkit_notify(CH_SECURITY);
        } else if (security_test_state == 4 && rpc->opcode == OP_ACL_SET && rpc->status == RPC_OK) {
            microkit_dbg_puts("ACL_SET_OK\n"); security_test_state=5;
            req(SVC_SECURITY, OP_ACL_CHECK, security_token, 0x1000); rpc->arg2=HERAIX_RIGHT_READ; microkit_notify(CH_SECURITY);
        } else if (security_test_state == 5 && rpc->opcode == OP_ACL_CHECK && rpc->status == RPC_OK) {
            microkit_dbg_puts("ACL_ALLOW_OK\n"); security_test_state=6;
            req(SVC_SECURITY, OP_ACL_CHECK, security_token, 0x1000); rpc->arg2=HERAIX_RIGHT_WRITE; microkit_notify(CH_SECURITY);
        } else if (security_test_state == 6 && rpc->opcode == OP_ACL_CHECK && rpc->status == RPC_PERMISSION) {
            microkit_dbg_puts("ACL_DENY_OK\n"); microkit_dbg_puts("SECURITY_ACL_OK\n");
            vfs_acl_test_state = 1;
            rpc->reserved = security_token;
            req(SVC_VFS, OP_VFS_READDIR, 0, 0);
            set_vfs_path("/system");
            microkit_notify(CH_VFS);
        } else { microkit_dbg_puts("SECURITY_TEST_FAIL\n"); }
    }
}
