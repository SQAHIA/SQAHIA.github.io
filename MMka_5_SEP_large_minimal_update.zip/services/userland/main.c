#include <microkit.h>
#include "heraix_rpc.h"
#include "heraix/api.h"
#include "heraix/system.h"
#include "heraix/memory.h"
#include "heraix/resource.h"
#include "heraix/device.h"
#include "heraix/file.h"

#define CH_ROOT     ((microkit_channel)0)
#define CH_SYSTEM   ((microkit_channel)1)
#define CH_MEMORY   ((microkit_channel)2)
#define CH_RESOURCE ((microkit_channel)3)
#define CH_DEVICE   ((microkit_channel)4)
#define CH_FILE     ((microkit_channel)5)
#define COMMAND_SIZE 256U
#define OUTPUT_SIZE 512U
#define FLOW_NONE 0U
#define FLOW_SIMPLE 1U
#define FLOW_LS 2U
#define FLOW_CD 3U
#define FLOW_CAT_STAT 4U
#define FLOW_CAT_OPEN 5U
#define FLOW_CAT_READ 6U
#define FLOW_CAT_CLOSE 7U
#define FLOW_WRITE_CREATE 8U
#define FLOW_WRITE_OPEN 9U
#define FLOW_WRITE_DATA 10U
#define FLOW_WRITE_CLOSE 11U
#define FLOW_MOUNT 12U
#define FLOW_INFO 13U
#define FLOW_MEMORY 14U
#define FLOW_RESOURCE 15U
#define FLOW_DEVICE 16U

static volatile heraix_rpc_t *rpc =
    (volatile heraix_rpc_t *)HERAIX_RPC_VADDR;
static volatile uint8_t *file_io = (volatile uint8_t *)HERAIX_VFS_IO_VADDR;
static volatile uint8_t *user_io =
    (volatile uint8_t *)HERAIX_USERLAND_IO_VADDR;
static uint32_t root_sequence;
static uint32_t service_sequence;
static uint32_t flow;
static uint64_t descriptor;
static uint64_t file_length;
static uint32_t command_length;
static uint32_t result_length;
static char arguments[3][128];
static char working_directory[128] = "/";
static char resolved_path[128];
static char write_data[128];

static uint32_t string_length(const char *text)
{
    uint32_t length = 0;
    while (text[length] != '\0') ++length;
    return length;
}

static void string_copy(char *destination, const char *source, uint32_t capacity)
{
    uint32_t index = 0;
    while (index + 1 < capacity && source[index] != '\0') {
        destination[index] = source[index];
        ++index;
    }
    destination[index] = '\0';
}

static int string_equal(const char *left, const char *right)
{
    uint32_t index = 0;
    while (left[index] != '\0' && right[index] != '\0') {
        if (left[index] != right[index]) return 0;
        ++index;
    }
    return left[index] == right[index];
}

static uint32_t buffer_length(const volatile uint8_t *buffer, uint32_t capacity)
{
    uint32_t length = 0;
    while (length < capacity && buffer[length] != 0) ++length;
    return length;
}

static void output_text(const char *text)
{
    uint32_t index = 0;
    while (index + 1 < OUTPUT_SIZE && text[index] != '\0') {
        user_io[HERAIX_USERLAND_OUTPUT_OFFSET + index] = (uint8_t)text[index];
        ++index;
    }
    user_io[HERAIX_USERLAND_OUTPUT_OFFSET + index] = 0;
    result_length = index;
    rpc->value0 = result_length;
}

static void finish(int32_t status, const char *text)
{
    if (text != 0) {
        output_text(text);
    } else {
        rpc->value0 = result_length;
    }
    rpc->service = SVC_USERLAND;
    rpc->opcode = OP_USERLAND_EXEC;
    rpc->seq = root_sequence;
    rpc->status = status;
    microkit_notify(CH_ROOT);
    flow = FLOW_NONE;
}

static void copy_vfs_path(const char *path)
{
    (void)heraix_path_store(file_io, HERAIX_VFS_DATA_OFFSET, path);
}

static void call_file_path(uint32_t opcode, const char *path, uint64_t arg0)
{
    ++service_sequence;
    (void)heraix_file_path_request(rpc, file_io, service_sequence, opcode, path);
    rpc->arg0 = arg0;
    microkit_notify(CH_FILE);
}

static void call_file_handle(uint32_t opcode, uint64_t handle, uint64_t arg)
{
    ++service_sequence;
    (void)heraix_file_handle_request(rpc, service_sequence, opcode, handle, arg);
    microkit_notify(CH_FILE);
}

static int parse_command(void)
{
    char line[COMMAND_SIZE];
    for (uint32_t index = 0; index < COMMAND_SIZE; ++index) {
        line[index] = (char)user_io[index];
        if (line[index] == '\0') break;
        if (index + 1 == COMMAND_SIZE) return 0;
    }
    for (uint32_t item = 0; item < 3; ++item) arguments[item][0] = '\0';
    uint32_t position = 0;
    uint32_t item = 0;
    while (line[position] == ' ') ++position;
    while (line[position] != '\0' && item < 3) {
        uint32_t length = 0;
        while (line[position] != '\0' && line[position] != ' ') {
            if (length + 1 >= sizeof(arguments[item])) return 0;
            arguments[item][length++] = line[position++];
        }
        arguments[item][length] = '\0';
        ++item;
        while (line[position] == ' ') ++position;
        if (item == 2 && arguments[0][0] != '\0' &&
            string_equal(arguments[0], "write")) {
            string_copy(write_data, &line[position], sizeof(write_data));
            item = 3;
            break;
        }
    }
    command_length = item;
    return arguments[0][0] != '\0';
}

static int resolve_path(const char *input, char *output, uint32_t capacity)
{
    if (input[0] == '/') {
        if (string_length(input) >= capacity) return 0;
        string_copy(output, input, capacity);
        return 1;
    }
    uint32_t cwd_length = string_length(working_directory);
    uint32_t input_length = string_length(input);
    uint32_t separator = string_equal(working_directory, "/") ? 0 : 1;
    if (cwd_length + separator + input_length + 1 > capacity) return 0;
    uint32_t index = 0;
    for (; index < cwd_length; ++index) output[index] = working_directory[index];
    if (separator) output[index++] = '/';
    for (uint32_t source = 0; source < input_length; ++source) {
        output[index++] = input[source];
    }
    output[index] = '\0';
    return 1;
}

static void send_service(uint32_t service, uint32_t opcode,
                         uint64_t arg0, uint64_t arg1)
{
    ++service_sequence;
    (void)heraix_rpc_prepare(rpc, service_sequence, service, opcode,
                             arg0, arg1, 0);
    microkit_notify(service == SVC_SYSTEM ? CH_SYSTEM :
                    service == SVC_MEMORY ? CH_MEMORY :
                    service == SVC_RESOURCE ? CH_RESOURCE : CH_DEVICE);
}

static void begin_command(void)
{
    char path[128];
    if (!parse_command()) {
        finish(RPC_BAD_REQUEST, "invalid command");
        return;
    }

    if (string_equal(arguments[0], "help")) {
        finish(RPC_OK, "help info mem resource device mount ls cd pwd cat write mkdir rm mv");
    } else if (string_equal(arguments[0], "pwd")) {
        finish(RPC_OK, working_directory);
    } else if (string_equal(arguments[0], "mkdir")) {
        if (command_length < 2 || !resolve_path(arguments[1], path, sizeof(path))) {
            finish(RPC_BAD_REQUEST, "mkdir: invalid path");
            return;
        }
        string_copy(resolved_path, path, sizeof(resolved_path));
        flow = FLOW_SIMPLE;
        call_file_path(OP_FILE_MKDIR, path, 0);
    } else if (string_equal(arguments[0], "rm")) {
        if (command_length < 2 || !resolve_path(arguments[1], path, sizeof(path))) {
            finish(RPC_BAD_REQUEST, "rm: invalid path");
            return;
        }
        string_copy(resolved_path, path, sizeof(resolved_path));
        flow = FLOW_SIMPLE;
        call_file_path(OP_FILE_UNLINK, path, 0);
    } else if (string_equal(arguments[0], "mv")) {
        char destination[128];
        if (command_length < 3 || !resolve_path(arguments[1], path, sizeof(path)) ||
            !resolve_path(arguments[2], destination, sizeof(destination))) {
            finish(RPC_BAD_REQUEST, "mv: invalid path");
            return;
        }
        string_copy(resolved_path, path, sizeof(resolved_path));
        copy_vfs_path(path);
        (void)heraix_path_store(file_io + HERAIX_VFS_DATA_OFFSET,
                                sizeof(destination), destination);
        ++service_sequence;
        (void)heraix_rpc_prepare(rpc, service_sequence, SVC_FILE,
                                 OP_FILE_RENAME, 0, 0, 0);
        flow = FLOW_SIMPLE;
        microkit_notify(CH_FILE);
    } else if (string_equal(arguments[0], "ls")) {
        const char *directory = command_length > 1 ? arguments[1] : working_directory;
        if (!resolve_path(directory, path, sizeof(path))) {
            finish(RPC_BAD_REQUEST, "ls: invalid path");
            return;
        }
        string_copy(resolved_path, path, sizeof(resolved_path));
        flow = FLOW_LS;
        call_file_path(OP_FILE_READDIR, path, 0);
    } else if (string_equal(arguments[0], "cd")) {
        if (command_length < 2 || !resolve_path(arguments[1], path, sizeof(path))) {
            finish(RPC_BAD_REQUEST, "cd: invalid path");
            return;
        }
        string_copy(resolved_path, path, sizeof(resolved_path));
        flow = FLOW_CD;
        call_file_path(OP_FILE_STAT, path, 0);
    } else if (string_equal(arguments[0], "cat")) {
        if (command_length < 2 || !resolve_path(arguments[1], path, sizeof(path))) {
            finish(RPC_BAD_REQUEST, "cat: invalid path");
            return;
        }
        string_copy(resolved_path, path, sizeof(resolved_path));
        flow = FLOW_CAT_STAT;
        call_file_path(OP_FILE_STAT, path, 0);
    } else if (string_equal(arguments[0], "write")) {
        if (command_length < 3 || !resolve_path(arguments[1], path, sizeof(path))) {
            finish(RPC_BAD_REQUEST, "write: invalid path or data");
            return;
        }
        string_copy(resolved_path, path, sizeof(resolved_path));
        flow = FLOW_WRITE_CREATE;
        call_file_path(OP_FILE_CREATE, path, 0);
    } else if (string_equal(arguments[0], "mount")) {
        flow = FLOW_MOUNT;
        call_file_path(OP_FILE_STAT, "/tmp", 0);
    } else if (string_equal(arguments[0], "info")) {
        flow = FLOW_INFO;
        send_service(SVC_SYSTEM, OP_GET_INFO, 1, 0);
    } else if (string_equal(arguments[0], "mem")) {
        flow = FLOW_MEMORY;
        send_service(SVC_MEMORY, OP_ALLOC, 1, 0);
    } else if (string_equal(arguments[0], "resource")) {
        flow = FLOW_RESOURCE;
        send_service(SVC_RESOURCE, OP_GET_RESOURCE, 1, 0);
    } else if (string_equal(arguments[0], "device")) {
        flow = FLOW_DEVICE;
        send_service(SVC_DEVICE, OP_DEVICE_LOOKUP, 0x8086, 0x7000);
    } else {
        finish(RPC_NOT_FOUND, "unknown command");
    }
}

void init(void)
{
}

void notified(microkit_channel ch)
{
    if (ch == CH_ROOT) {
        if (!heraix_rpc_valid_request(rpc, SVC_USERLAND) ||
            rpc->opcode != OP_USERLAND_EXEC) {
            rpc->service = SVC_USERLAND;
            rpc->status = RPC_BAD_REQUEST;
            microkit_notify(CH_ROOT);
            return;
        }
        root_sequence = rpc->seq;
        result_length = 0;
        begin_command();
        return;
    }

    if (ch == CH_FILE) {
        if (!heraix_rpc_valid_request(rpc, SVC_FILE) ||
            rpc->seq != service_sequence) {
            finish(RPC_BAD_REQUEST, "file service protocol error");
            return;
        }
        int32_t status = rpc->status;
        if (flow == FLOW_SIMPLE) {
            finish(status, status == RPC_OK ? "ok" : "file operation failed");
        } else if (flow == FLOW_LS) {
            uint32_t length = buffer_length(file_io, HERAIX_VFS_DATA_OFFSET);
            for (uint32_t index = 0; index <= length; ++index) {
                user_io[HERAIX_USERLAND_OUTPUT_OFFSET + index] = file_io[index];
            }
            result_length = length;
            finish(status, 0);
        } else if (flow == FLOW_CD) {
            if (status == RPC_OK && rpc->value1 == 2) {
                string_copy(working_directory, resolved_path, sizeof(working_directory));
                finish(RPC_OK, working_directory);
            } else {
                finish(status == RPC_OK ? RPC_NOT_FOUND : status, "cd failed");
            }
        } else if (flow == FLOW_CAT_STAT && status == RPC_OK) {
            microkit_dbg_puts("USERLAND_CAT_STAT_OK\n");
            file_length = rpc->value0;
            if (file_length > OUTPUT_SIZE - 1) file_length = OUTPUT_SIZE - 1;
            ++service_sequence;
            (void)heraix_file_open(rpc, file_io, service_sequence,
                                   resolved_path, 1);
            flow = FLOW_CAT_OPEN;
            microkit_notify(CH_FILE);
        } else if (flow == FLOW_CAT_OPEN && status == RPC_OK) {
            microkit_dbg_puts("USERLAND_CAT_OPEN_OK\n");
            descriptor = rpc->value0;
            if (file_length == 0) {
                result_length = 0;
                flow = FLOW_CAT_CLOSE;
                call_file_handle(OP_FILE_CLOSE, descriptor, 0);
                return;
            }
            flow = FLOW_CAT_READ;
            call_file_handle(OP_FILE_READ, descriptor, file_length);
        } else if (flow == FLOW_CAT_READ && status == RPC_OK) {
            microkit_dbg_puts("USERLAND_CAT_READ_OK\n");
            uint64_t amount = rpc->value0;
            for (uint64_t index = 0; index < amount; ++index) {
                user_io[HERAIX_USERLAND_OUTPUT_OFFSET + index] =
                    file_io[HERAIX_VFS_DATA_OFFSET + index];
            }
            user_io[HERAIX_USERLAND_OUTPUT_OFFSET + amount] = 0;
            result_length = (uint32_t)amount;
            flow = FLOW_CAT_CLOSE;
            call_file_handle(OP_FILE_CLOSE, descriptor, 0);
        } else if (flow == FLOW_CAT_CLOSE) {
            finish(status, 0);
        } else if (flow == FLOW_WRITE_CREATE && status == RPC_OK) {
            ++service_sequence;
            (void)heraix_file_open(rpc, file_io, service_sequence,
                                   resolved_path, 2);
            flow = FLOW_WRITE_OPEN;
            microkit_notify(CH_FILE);
        } else if (flow == FLOW_WRITE_OPEN && status == RPC_OK) {
            descriptor = rpc->value0;
            uint32_t length = string_length(write_data);
            (void)heraix_path_store(file_io + HERAIX_VFS_DATA_OFFSET,
                                    HERAIX_BLOCK_SIZE - HERAIX_VFS_DATA_OFFSET,
                                    write_data);
            flow = FLOW_WRITE_DATA;
            call_file_handle(OP_FILE_WRITE, descriptor, length);
        } else if (flow == FLOW_WRITE_DATA && status == RPC_OK) {
            flow = FLOW_WRITE_CLOSE;
            call_file_handle(OP_FILE_CLOSE, descriptor, 0);
        } else if (flow == FLOW_WRITE_CLOSE) {
            finish(status, status == RPC_OK ? "written" : "write failed");
        } else if (flow == FLOW_MOUNT) {
            finish(status, status == RPC_OK ? "/\n/tmp" : "mount query failed");
        } else if (flow == FLOW_CAT_STAT || flow == FLOW_CAT_OPEN ||
                   flow == FLOW_CAT_READ) {
            microkit_dbg_puts("USERLAND_CAT_BACKEND_ERROR\n");
            finish(status, "cat backend error");
        } else {
            finish(status, "file service operation failed");
        }
        return;
    }

    if (ch == CH_SYSTEM || ch == CH_MEMORY ||
        ch == CH_RESOURCE || ch == CH_DEVICE) {
        if (rpc->seq != service_sequence || rpc->status != RPC_OK) {
            finish(rpc->status == RPC_OK ? RPC_BAD_REQUEST : rpc->status,
                   "service request failed");
        } else if (flow == FLOW_INFO) {
            finish(RPC_OK, "system ready");
        } else if (flow == FLOW_MEMORY) {
            finish(RPC_OK, "memory allocated");
        } else if (flow == FLOW_RESOURCE) {
            finish(RPC_OK, "resources available");
        } else if (flow == FLOW_DEVICE) {
            if (rpc->value0 != 0x8086 || rpc->value1 != 0x7000) {
                finish(RPC_NOT_FOUND, "device not found");
            } else {
                finish(RPC_OK, "8086:7000");
            }
        }
    }
}