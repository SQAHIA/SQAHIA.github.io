#include <microkit.h>
#include "heraix_rpc.h"
#include "heraix/api.h"

#define CH_ROOT ((microkit_channel)0)
#define CH_USERLAND ((microkit_channel)1)
#define PCI_CONFIG_ADDRESS 0xcf8u
#define PCI_CONFIG_DATA    0xcfcu
#define PCI_ENABLE         0x80000000u
#define PCI_DEVICE_LIMIT   256u

uint64_t pci_config_ioport_id;

typedef struct {
    uint8_t bus;
    uint8_t device;
    uint8_t function;
    uint8_t class_code;
    uint8_t subclass;
    uint16_t vendor;
    uint16_t product;
} pci_device_t;

static volatile heraix_rpc_t *rpc =
    (volatile heraix_rpc_t *)HERAIX_RPC_VADDR;
static pci_device_t devices[PCI_DEVICE_LIMIT];
static uint32_t device_count;

static uint32_t pci_read32(uint8_t bus, uint8_t device, uint8_t function,
                           uint8_t offset)
{
    uint32_t address = PCI_ENABLE | ((uint32_t)bus << 16) |
                       ((uint32_t)device << 11) |
                       ((uint32_t)function << 8) | (offset & 0xfcu);
    microkit_x86_ioport_write_32(pci_config_ioport_id, PCI_CONFIG_ADDRESS, address);
    return microkit_x86_ioport_read_32(pci_config_ioport_id, PCI_CONFIG_DATA);
}

static void register_function(uint8_t bus, uint8_t device, uint8_t function)
{
    uint32_t identity = pci_read32(bus, device, function, 0x00);
    uint16_t vendor = (uint16_t)identity;
    if (vendor == 0xffffu || device_count == PCI_DEVICE_LIMIT) {
        return;
    }

    uint32_t class_info = pci_read32(bus, device, function, 0x08);
    pci_device_t *entry = &devices[device_count++];
    entry->bus = bus;
    entry->device = device;
    entry->function = function;
    entry->class_code = (uint8_t)(class_info >> 24);
    entry->subclass = (uint8_t)(class_info >> 16);
    entry->vendor = vendor;
    entry->product = (uint16_t)(identity >> 16);
}

static void discover_bus_zero(void)
{
    for (uint8_t device = 0; device < 32; ++device) {
        uint32_t identity = pci_read32(0, device, 0, 0x00);
        if ((uint16_t)identity == 0xffffu) {
            continue;
        }

        register_function(0, device, 0);
        uint8_t header_type = (uint8_t)(pci_read32(0, device, 0, 0x0c) >> 16);
        if ((header_type & 0x80u) != 0) {
            for (uint8_t function = 1; function < 8; ++function) {
                register_function(0, device, function);
            }
        }
    }
}

void init(void)
{
    discover_bus_zero();
}

void notified(microkit_channel ch)
{
    if (ch != CH_ROOT && ch != CH_USERLAND) {
        return;
    }

    if (!heraix_rpc_valid_request(rpc, SVC_DEVICE)) {
        rpc->status = RPC_BAD_REQUEST;
        microkit_notify(ch);
        return;
    }

    if (rpc->opcode != OP_DEVICE_LOOKUP ||
        rpc->arg0 > 0xffffu || rpc->arg1 > 0xffffu) {
        rpc->status = RPC_BAD_REQUEST;
        microkit_notify(ch);
        return;
    }

    for (uint32_t index = 0; index < device_count; ++index) {
        const pci_device_t *entry = &devices[index];
        if (entry->vendor != rpc->arg0 || entry->product != rpc->arg1) {
            continue;
        }

        uint32_t live_identity = pci_read32(entry->bus, entry->device,
                                            entry->function, 0x00);
        if ((uint16_t)live_identity != entry->vendor ||
            (uint16_t)(live_identity >> 16) != entry->product) {
            rpc->status = RPC_NOT_FOUND;
            microkit_notify(ch);
            return;
        }

        rpc->status = RPC_OK;
        rpc->value0 = (uint16_t)live_identity;
        rpc->value1 = (uint16_t)(live_identity >> 16);
        rpc->value2 = HERAIX_DEVICE_OWNER_DEVICE_SERVICE;
        rpc->value3 = ((uint32_t)entry->bus << 8) |
                      ((uint32_t)entry->device << 3) | entry->function;
        microkit_notify(ch);
        return;
    }

    rpc->status = RPC_NOT_FOUND;
    microkit_notify(ch);
}