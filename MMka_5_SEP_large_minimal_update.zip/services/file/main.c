#include <microkit.h>
#include "heraix_rpc.h"
#include "heraix/api.h"

#define CH_ROOT ((microkit_channel)0)
#define CH_VFS  ((microkit_channel)1)
#define CH_USERLAND ((microkit_channel)2)
#define FILE_HANDLE_COUNT 8U
#define NO_HANDLE 0xffffffffu

typedef struct {
    uint32_t used;
    uint64_t vfs_handle;
    uint64_t generation;
} file_handle_t;

static volatile heraix_rpc_t *rpc =
    (volatile heraix_rpc_t *)HERAIX_RPC_VADDR;
static file_handle_t handles[FILE_HANDLE_COUNT];
static uint32_t pending_opcode;
static uint32_t pending_sequence;
static uint32_t pending_handle_index;
static uint64_t pending_vfs_handle;
static uint64_t pending_handle_generation;
static microkit_channel pending_client_channel;

static void reply_root(int32_t status)
{
    rpc->service = SVC_FILE;
    rpc->status = status;
    microkit_notify(pending_client_channel);
}

static uint32_t vfs_opcode(uint32_t opcode)
{
    switch (opcode) {
    case OP_FILE_OPEN: return OP_VFS_OPEN;
    case OP_FILE_CLOSE: return OP_VFS_CLOSE;
    case OP_FILE_READ: return OP_VFS_READ;
    case OP_FILE_WRITE: return OP_VFS_WRITE;
    case OP_FILE_SEEK: return OP_VFS_SEEK;
    case OP_FILE_STAT: return OP_VFS_STAT;
    case OP_FILE_READDIR: return OP_VFS_READDIR;
    case OP_FILE_CREATE: return OP_VFS_CREATE;
    case OP_FILE_UNLINK: return OP_VFS_UNLINK;
    case OP_FILE_RENAME: return OP_VFS_RENAME;
    case OP_FILE_MKDIR: return OP_VFS_MKDIR;
    default: return 0;
    }
}

static int needs_handle(uint32_t opcode)
{
    return opcode == OP_FILE_CLOSE || opcode == OP_FILE_READ ||
           opcode == OP_FILE_WRITE || opcode == OP_FILE_SEEK;
}

void init(void)
{
}

void notified(microkit_channel ch)
{
    if (ch == CH_VFS) {
        if (!heraix_rpc_valid_request(rpc, SVC_VFS) ||
            rpc->seq != pending_sequence) {
            reply_root(RPC_BAD_REQUEST);
            return;
        }
        int32_t status = rpc->status;
        rpc->service = SVC_FILE;
        rpc->opcode = pending_opcode;
        rpc->seq = pending_sequence;
        if (pending_opcode == OP_FILE_OPEN && status == RPC_OK) {
            if (pending_handle_index == NO_HANDLE) {
                status = RPC_NO_MEMORY;
            } else {
                handles[pending_handle_index].used = 1;
                handles[pending_handle_index].vfs_handle = rpc->value0;
                handles[pending_handle_index].generation = pending_handle_generation;
                rpc->value0 = (pending_handle_generation << 8) |
                              (pending_handle_index + 1);
            }
        } else if (pending_opcode == OP_FILE_CLOSE && status == RPC_OK) {
            handles[pending_handle_index].used = 0;
        }
        reply_root(status);
        return;
    }

    if (ch != CH_ROOT && ch != CH_USERLAND) {
        return;
    }
    pending_client_channel = ch;
    if (!heraix_rpc_valid_request(rpc, SVC_FILE)) {
        reply_root(RPC_BAD_REQUEST);
        return;
    }

    uint32_t backend_opcode = vfs_opcode(rpc->opcode);
    if (backend_opcode == 0) {
        reply_root(RPC_BAD_REQUEST);
        return;
    }

    pending_opcode = rpc->opcode;
    pending_sequence = rpc->seq;
    pending_handle_index = NO_HANDLE;
    pending_vfs_handle = 0;
    pending_handle_generation = 0;
    if (rpc->opcode == OP_FILE_OPEN) {
        for (uint32_t index = 0; index < FILE_HANDLE_COUNT; ++index) {
            if (!handles[index].used) {
                pending_handle_index = index;
                break;
            }
        }
        if (pending_handle_index == NO_HANDLE) {
            reply_root(RPC_NO_MEMORY);
            return;
        }
        pending_handle_generation =
            handles[pending_handle_index].generation + 1;
        if (pending_handle_generation == 0) {
            pending_handle_generation = 1;
        }
    } else if (needs_handle(rpc->opcode)) {
        uint64_t descriptor = rpc->arg0;
        uint64_t slot = descriptor & 0xffu;
        uint64_t generation = descriptor >> 8;
        if (slot == 0 || slot > FILE_HANDLE_COUNT || generation == 0 ||
            !handles[slot - 1].used ||
            handles[slot - 1].generation != generation) {
            reply_root(RPC_INVALID_HANDLE);
            return;
        }
        pending_handle_index = (uint32_t)(slot - 1);
        pending_vfs_handle = handles[pending_handle_index].vfs_handle;
    }

    rpc->service = SVC_VFS;
    rpc->opcode = backend_opcode;
    if (needs_handle(pending_opcode)) {
        rpc->arg0 = pending_vfs_handle;
    }
    microkit_notify(CH_VFS);
}