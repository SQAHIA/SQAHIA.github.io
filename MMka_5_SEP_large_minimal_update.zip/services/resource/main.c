#include <microkit.h>
#include "heraix_rpc.h"
#include "heraix/api.h"

#define CH_ROOT ((microkit_channel)0)
#define CH_USERLAND ((microkit_channel)1)

static volatile heraix_rpc_t *rpc =
    (volatile heraix_rpc_t *)HERAIX_RPC_VADDR;

void init(void)
{
}

void notified(microkit_channel ch)
{
    if (ch != CH_ROOT && ch != CH_USERLAND) return;

    if (!heraix_rpc_valid_request(rpc, SVC_RESOURCE) ||
        rpc->opcode != OP_GET_RESOURCE) {
        rpc->status = RPC_BAD_REQUEST;
        microkit_notify(ch);
        return;
    }

    rpc->status = RPC_OK;
    rpc->value0 = HERAIX_POOL_SIZE;
    rpc->value1 = HERAIX_BLOCK_SIZE;
    rpc->value2 = HERAIX_BLOCK_COUNT;
    microkit_notify(ch);
}
