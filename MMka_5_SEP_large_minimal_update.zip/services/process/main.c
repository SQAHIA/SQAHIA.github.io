#include <microkit.h>
#include "heraix_rpc.h"
#include "heraix/api.h"
#include "heraix/process.h"

#define CH_ROOT ((microkit_channel)0)
#define PROCESS_LIMIT 8U
#define THREAD_LIMIT 16U
#define PROCESS_RUNNING 1U
#define PROCESS_EXITED 2U
#define EVENT_LIMIT 8U

typedef struct {
    uint32_t used, pid, parent, state, threads;
    uint32_t owner, token, resource_blocks, ipc_identity, service_permissions;
    char name[HERAIX_PROCESS_NAME_MAX];
} process_t;
typedef struct {
    uint32_t used, tid, pid, state, resource_blocks;
    char name[HERAIX_PROCESS_NAME_MAX];
} thread_t;
typedef struct {
    uint32_t sequence, type, pid, tid, state;
} event_t;

static volatile heraix_rpc_t *rpc = (volatile heraix_rpc_t *)HERAIX_RPC_VADDR;
static process_t processes[PROCESS_LIMIT];
static thread_t threads[THREAD_LIMIT];
static event_t events[EVENT_LIMIT];
static uint32_t next_pid = 2U;
static uint32_t next_tid = 2U;
static uint32_t event_head;
static uint32_t event_count;
static uint32_t next_event_sequence = 1U;

static int valid_request(void) {
    return heraix_rpc_valid_request(rpc, SVC_PROCESS);
}
static process_t *find_process(uint32_t pid) {
    for (uint32_t i = 0; i < PROCESS_LIMIT; ++i)
        if (processes[i].used && processes[i].pid == pid) return &processes[i];
    return 0;
}
static thread_t *find_thread(uint32_t tid) {
    for (uint32_t i = 0; i < THREAD_LIMIT; ++i)
        if (threads[i].used && threads[i].tid == tid) return &threads[i];
    return 0;
}
static void reply(int32_t status) {
    rpc->service = SVC_PROCESS;
    rpc->status = status;
    microkit_notify(CH_ROOT);
}
static int valid_name(uint64_t packed) {
    if (packed == 0) return 1;
    for (uint32_t i = 0; i < HERAIX_PROCESS_NAME_MAX; ++i)
        if (((packed >> (i * 8U)) & 0xffU) == 0) return 1;
    return 0;
}
static void store_name(char destination[HERAIX_PROCESS_NAME_MAX],
                       uint64_t packed, const char *fallback) {
    uint32_t i = 0;
    if (packed != 0) {
        for (; i < HERAIX_PROCESS_NAME_MAX; ++i) {
            destination[i] = (char)((packed >> (i * 8U)) & 0xffU);
            if (destination[i] == '\0') return;
        }
    }
    for (i = 0; i + 1U < HERAIX_PROCESS_NAME_MAX && fallback[i] != '\0'; ++i)
        destination[i] = fallback[i];
    destination[i] = '\0';
}
static uint64_t packed_name(const char name[HERAIX_PROCESS_NAME_MAX]) {
    uint64_t packed = 0;
    for (uint32_t i = 0; i < HERAIX_PROCESS_NAME_MAX; ++i) {
        packed |= ((uint64_t)(uint8_t)name[i]) << (i * 8U);
        if (name[i] == '\0') break;
    }
    return packed;
}
static void publish_event(uint32_t type, uint32_t pid, uint32_t tid,
                          uint32_t state) {
    uint32_t index;
    if (event_count == EVENT_LIMIT) {
        index = event_head;
        event_head = (event_head + 1U) % EVENT_LIMIT;
    } else {
        index = (event_head + event_count) % EVENT_LIMIT;
        ++event_count;
    }
    events[index].sequence = next_event_sequence++;
    if (next_event_sequence == 0) next_event_sequence = 1U;
    events[index].type = type;
    events[index].pid = pid;
    events[index].tid = tid;
    events[index].state = state;
}

void init(void) {
    processes[0] = (process_t){1, 1, 0, PROCESS_RUNNING, 1,
                               0, 1, 1, 1, 0xffffffffU, {0}};
    threads[0] = (thread_t){1, 1, 1, PROCESS_RUNNING, 1, {0}};
    store_name(processes[0].name, 0, "root");
    store_name(threads[0].name, 0, "root");
}

void notified(microkit_channel ch) {
    if (ch != CH_ROOT || !valid_request()) {
        if (ch == CH_ROOT) reply(RPC_BAD_REQUEST);
        return;
    }
    rpc->value0 = rpc->value1 = rpc->value2 = rpc->value3 = 0;
    rpc->used_blocks = rpc->reserved = 0;
    if (rpc->opcode == OP_PROCESS_CREATE) {
        if (rpc->arg0 > 0xffffffffU || rpc->arg1 > 0xffffffffU ||
            !valid_name(rpc->arg2)) { reply(RPC_INVALID_RANGE); return; }
        process_t *parent = find_process((uint32_t)rpc->arg0);
        if (!parent || parent->state != PROCESS_RUNNING) { reply(RPC_NOT_FOUND); return; }
        process_t *p = 0; thread_t *t = 0;
        for (uint32_t i = 0; i < PROCESS_LIMIT; ++i) if (!processes[i].used) { p = &processes[i]; break; }
        for (uint32_t i = 0; i < THREAD_LIMIT; ++i) if (!threads[i].used) { t = &threads[i]; break; }
        if (!p || !t) { reply(RPC_NO_MEMORY); return; }
        *p = (process_t){0};
        p->used = 1; p->pid = next_pid++; p->parent = parent->pid; p->state = PROCESS_RUNNING; p->threads = 1;
        p->owner = (uint32_t)rpc->arg1; p->token = p->owner == 0 ? 1U : p->owner + 1U;
        p->resource_blocks = 1; p->ipc_identity = p->pid; p->service_permissions = 0xffffffffU;
        store_name(p->name, rpc->arg2, "process");
        *t = (thread_t){0};
        t->used = 1; t->tid = next_tid++; t->pid = p->pid; t->state = PROCESS_RUNNING; t->resource_blocks = 1;
        store_name(t->name, 0, "main");
        publish_event(HERAIX_PROCESS_EVENT_CREATED, p->pid, t->tid, p->state);
        rpc->value0 = p->pid; rpc->value1 = t->tid; reply(RPC_OK); return;
    }
    if (rpc->opcode == OP_PROCESS_QUERY) {
        process_t *p = find_process((uint32_t)rpc->arg0);
        if (!p) { reply(RPC_NOT_FOUND); return; }
        rpc->value0 = p->state; rpc->value1 = p->threads; rpc->value2 = p->parent; rpc->value3 = p->owner;
        rpc->used_blocks = p->resource_blocks; rpc->reserved = p->token; rpc->arg2 = p->service_permissions;
        reply(RPC_OK); return;
    }
    if (rpc->opcode == OP_PROCESS_ENUMERATE) {
        if (rpc->arg0 > PROCESS_LIMIT) { reply(RPC_INVALID_RANGE); return; }
        for (uint32_t i = (uint32_t)rpc->arg0; i < PROCESS_LIMIT; ++i) {
            process_t *p = &processes[i];
            if (!p->used) continue;
            rpc->value0 = p->pid; rpc->value1 = p->state;
            rpc->value2 = p->parent; rpc->value3 = p->owner;
            rpc->arg2 = packed_name(p->name); rpc->used_blocks = p->resource_blocks;
            rpc->reserved = i + 1U;
            reply(RPC_OK); return;
        }
        reply(RPC_NOT_FOUND); return;
    }
    if (rpc->opcode == OP_PROCESS_EVENT_QUERY) {
        if (rpc->arg0 > 0xffffffffU) { reply(RPC_INVALID_RANGE); return; }
        for (uint32_t i = 0; i < event_count; ++i) {
            event_t *event = &events[(event_head + i) % EVENT_LIMIT];
            if (event->sequence <= (uint32_t)rpc->arg0) continue;
            rpc->value0 = event->sequence; rpc->value1 = event->type;
            rpc->value2 = event->pid; rpc->value3 = event->tid;
            rpc->arg0 = event->state; rpc->used_blocks = event_count;
            reply(RPC_OK); return;
        }
        reply(RPC_NOT_FOUND); return;
    }
    if (rpc->opcode == OP_THREAD_CREATE) {
        process_t *p = find_process((uint32_t)rpc->arg0); thread_t *t = 0;
        if (!p || p->state != PROCESS_RUNNING) { reply(RPC_NOT_FOUND); return; }
        for (uint32_t i = 0; i < THREAD_LIMIT; ++i) if (!threads[i].used) { t = &threads[i]; break; }
        if (!t) { reply(RPC_NO_MEMORY); return; }
        *t = (thread_t){0};
        t->used = 1; t->tid = next_tid++; t->pid = p->pid; t->state = PROCESS_RUNNING; t->resource_blocks = 1;
        store_name(t->name, 0, "thread");
        ++p->threads;
        publish_event(HERAIX_PROCESS_EVENT_THREAD_CREATE, p->pid, t->tid, t->state);
        rpc->value0 = t->tid; rpc->value1 = p->pid; reply(RPC_OK); return;
    }
    if (rpc->opcode == OP_THREAD_QUERY) {
        thread_t *t = find_thread((uint32_t)rpc->arg0);
        if (!t) { reply(RPC_NOT_FOUND); return; }
        rpc->value0 = t->state; rpc->value1 = t->pid; rpc->used_blocks = t->resource_blocks; reply(RPC_OK); return;
    }
    if (rpc->opcode == OP_THREAD_EXIT) {
        thread_t *t = find_thread((uint32_t)rpc->arg0);
        if (!t || t->tid == 1 || t->state == PROCESS_EXITED) { reply(RPC_INVALID_HANDLE); return; }
        process_t *p = find_process(t->pid); t->state = PROCESS_EXITED; t->used = 0;
        if (p && p->threads) --p->threads;
        publish_event(HERAIX_PROCESS_EVENT_THREAD_EXIT, t->pid, t->tid, t->state);
        reply(RPC_OK); return;
    }
    if (rpc->opcode == OP_PROCESS_EXIT) {
        process_t *p = find_process((uint32_t)rpc->arg0);
        if (!p || p->pid == 1 || p->state == PROCESS_EXITED) { reply(RPC_INVALID_HANDLE); return; }
        p->state = PROCESS_EXITED;
        publish_event(HERAIX_PROCESS_EVENT_EXIT, p->pid, 0, p->state);
        reply(RPC_OK); return;
    }
    reply(RPC_BAD_REQUEST);
}
