#include <microkit.h>
#include "heraix_rpc.h"
#include "heraix/api.h"

#define CH_ROOT ((microkit_channel)0)
#define CH_USERLAND ((microkit_channel)1)

static volatile heraix_rpc_t *rpc =
    (volatile heraix_rpc_t *)HERAIX_RPC_VADDR;

static uint32_t bitmap;

void init(void)
{
}

void notified(microkit_channel ch)
{
    if (ch != CH_ROOT && ch != CH_USERLAND) return;

    if (!heraix_rpc_valid_request(rpc, SVC_MEMORY) ||
        (rpc->opcode != OP_ALLOC && rpc->opcode != OP_FREE) ||
        (rpc->opcode == OP_ALLOC && rpc->arg0 != 1)) {
        rpc->status = RPC_BAD_REQUEST;
        microkit_notify(ch);
        return;
    }

    if (rpc->opcode == OP_FREE) {
        if (rpc->arg0 >= HERAIX_POOL_SIZE ||
            (rpc->arg0 % HERAIX_BLOCK_SIZE) != 0) {
            rpc->status = RPC_INVALID_RANGE;
            microkit_notify(ch);
            return;
        }
        uint32_t block = (uint32_t)(rpc->arg0 / HERAIX_BLOCK_SIZE);
        if (!(bitmap & (1U << block))) {
            rpc->status = RPC_INVALID_HANDLE;
            microkit_notify(ch);
            return;
        }
        bitmap &= ~(1U << block);
        rpc->status = RPC_OK;
        rpc->used_blocks = 0;
        for (uint32_t i = 0; i < HERAIX_BLOCK_COUNT; ++i)
            if (bitmap & (1U << i)) ++rpc->used_blocks;
        microkit_notify(ch);
        return;
    }

    uint32_t block = HERAIX_BLOCK_COUNT;

    for (uint32_t i = 0; i < HERAIX_BLOCK_COUNT; ++i) {
        if (!(bitmap & (1U << i))) {
            block = i;
            break;
        }
    }

    if (block == HERAIX_BLOCK_COUNT) {
        rpc->status = RPC_NO_MEMORY;
        microkit_notify(ch);
        return;
    }

    bitmap |= 1U << block;
    rpc->status = RPC_OK;
    rpc->value0 = (uint64_t)block * HERAIX_BLOCK_SIZE;
    rpc->value1 = HERAIX_BLOCK_SIZE;

    uint32_t used = 0;
    for (uint32_t i = 0; i < HERAIX_BLOCK_COUNT; ++i)
        if (bitmap & (1U << i)) ++used;

    rpc->used_blocks = used;
    microkit_notify(ch);
}
