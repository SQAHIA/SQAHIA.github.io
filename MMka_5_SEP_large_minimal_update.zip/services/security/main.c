#include <microkit.h>
#include "heraix_rpc.h"
#include "heraix/api.h"
#include "heraix/security.h"

#define CH_ROOT ((microkit_channel)0)
#define CH_VFS  ((microkit_channel)1)
#define USER_LIMIT 8U
#define GROUP_LIMIT 8U
#define TOKEN_LIMIT 8U
#define ACL_LIMIT 16U

typedef struct { uint32_t used, uid; } user_t;
typedef struct { uint32_t used, gid; uint32_t members[USER_LIMIT]; } group_t;
typedef struct { uint32_t used, token, uid, revoked; } token_t;
typedef struct { uint32_t used; uint64_t object; uint32_t uid, rights; } acl_t;

static volatile heraix_rpc_t *rpc = (volatile heraix_rpc_t *)HERAIX_RPC_VADDR;
static user_t users[USER_LIMIT]; static group_t groups[GROUP_LIMIT];
static token_t tokens[TOKEN_LIMIT]; static acl_t acls[ACL_LIMIT];
static uint32_t next_token = 2U;
static microkit_channel reply_channel = CH_ROOT;

static int valid_request(void) { return heraix_rpc_valid_request(rpc, SVC_SECURITY); }
static user_t *user(uint32_t uid) { for (uint32_t i=0;i<USER_LIMIT;++i) if(users[i].used&&users[i].uid==uid)return &users[i]; return 0; }
static group_t *group(uint32_t gid) { for (uint32_t i=0;i<GROUP_LIMIT;++i) if(groups[i].used&&groups[i].gid==gid)return &groups[i]; return 0; }
static token_t *token(uint32_t id) { for (uint32_t i=0;i<TOKEN_LIMIT;++i) if(tokens[i].used&&tokens[i].token==id)return &tokens[i]; return 0; }
static void reply(int32_t status) { rpc->service=SVC_SECURITY; rpc->status=status; microkit_notify(reply_channel); }

void init(void) { users[0]=(user_t){1,0}; tokens[0]=(token_t){1,1,0,0}; }
void notified(microkit_channel ch) {
    if (ch!=CH_ROOT && ch!=CH_VFS) return;
    reply_channel = ch;
    if (!valid_request()) { reply(RPC_BAD_REQUEST); return; }
    rpc->value0=rpc->value1=rpc->value2=rpc->value3=0;
    if (rpc->opcode==OP_USER_CREATE) { if(user((uint32_t)rpc->arg0)){reply(RPC_ALREADY_EXISTS);return;} for(uint32_t i=0;i<USER_LIMIT;++i)if(!users[i].used){users[i]=(user_t){1,(uint32_t)rpc->arg0};rpc->value0=rpc->arg0;reply(RPC_OK);return;} reply(RPC_NO_MEMORY);return; }
    if (rpc->opcode==OP_GROUP_CREATE) { if(group((uint32_t)rpc->arg0)){reply(RPC_ALREADY_EXISTS);return;} for(uint32_t i=0;i<GROUP_LIMIT;++i)if(!groups[i].used){groups[i].used=1;groups[i].gid=(uint32_t)rpc->arg0;rpc->value0=rpc->arg0;reply(RPC_OK);return;} reply(RPC_NO_MEMORY);return; }
    if (rpc->opcode==OP_GROUP_ADD_MEMBER) { group_t*g=group((uint32_t)rpc->arg1); if(!user((uint32_t)rpc->arg0)||!g){reply(RPC_NOT_FOUND);return;} for(uint32_t i=0;i<USER_LIMIT;++i)if(!g->members[i]){g->members[i]=(uint32_t)rpc->arg0;reply(RPC_OK);return;} reply(RPC_NO_MEMORY);return; }
    if (rpc->opcode==OP_TOKEN_ISSUE) { if(!user((uint32_t)rpc->arg0)){reply(RPC_NOT_FOUND);return;} for(uint32_t i=0;i<TOKEN_LIMIT;++i)if(!tokens[i].used){tokens[i]=(token_t){1,next_token++,(uint32_t)rpc->arg0,0};rpc->value0=tokens[i].token;reply(RPC_OK);return;} reply(RPC_NO_MEMORY);return; }
    if (rpc->opcode==OP_TOKEN_REVOKE) { token_t*t=token((uint32_t)rpc->arg0); if(!t){reply(RPC_INVALID_HANDLE);return;} t->revoked=1;reply(RPC_OK);return; }
    if (rpc->opcode==OP_ACL_SET) { if(!user((uint32_t)rpc->arg1)){reply(RPC_NOT_FOUND);return;} for(uint32_t i=0;i<ACL_LIMIT;++i)if(!acls[i].used||(acls[i].object==rpc->arg0&&acls[i].uid==(uint32_t)rpc->arg1)){acls[i]=(acl_t){1,rpc->arg0,(uint32_t)rpc->arg1,(uint32_t)rpc->arg2};reply(RPC_OK);return;} reply(RPC_NO_MEMORY);return; }
    if (rpc->opcode==OP_ACL_CHECK) { token_t*t=token((uint32_t)rpc->arg0); if(!t||t->revoked){reply(RPC_PERMISSION);return;} if(t->uid==0){reply(RPC_OK);return;} for(uint32_t i=0;i<ACL_LIMIT;++i)if(acls[i].used&&acls[i].object==rpc->arg1&&acls[i].uid==t->uid){if((acls[i].rights&(uint32_t)rpc->arg2)==(uint32_t)rpc->arg2){reply(RPC_OK);return;}break;} reply(RPC_PERMISSION);return; }
    reply(RPC_BAD_REQUEST);
}
