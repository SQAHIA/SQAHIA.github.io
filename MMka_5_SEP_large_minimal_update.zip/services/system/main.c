#include <microkit.h>
#include "heraix_rpc.h"
#include "heraix/api.h"

#define CH_ROOT ((microkit_channel)0)
#define CH_USERLAND ((microkit_channel)1)

static volatile heraix_rpc_t *rpc =
    (volatile heraix_rpc_t *)HERAIX_RPC_VADDR;

void init(void)
{
}

void notified(microkit_channel ch)
{
    if (ch != CH_ROOT && ch != CH_USERLAND) return;

    if (!heraix_rpc_valid_request(rpc, SVC_SYSTEM) ||
        (rpc->opcode != OP_GET_INFO && rpc->opcode != OP_GET_HEALTH)) {
        rpc->status = RPC_BAD_REQUEST;
    } else if (rpc->opcode == OP_GET_HEALTH) {
        rpc->status = RPC_OK;
        rpc->value0 = 11;
        rpc->value1 = 1;
    } else {
        rpc->status = RPC_OK;
        rpc->value0 = 0x10000;
        rpc->value1 = 0x4D4D4B41;
    }

    microkit_notify(ch);
}
