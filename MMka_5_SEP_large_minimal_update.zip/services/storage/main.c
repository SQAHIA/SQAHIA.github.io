#include <microkit.h>
#include "heraix_rpc.h"
#include "heraix/api.h"

#define CH_ROOT ((microkit_channel)0)
#define CH_VFS  ((microkit_channel)1)

static volatile heraix_rpc_t *rpc =
    (volatile heraix_rpc_t *)HERAIX_RPC_VADDR;
static volatile uint8_t *io_buffer =
    (volatile uint8_t *)HERAIX_STORAGE_IO_VADDR;
static uint8_t blocks[HERAIX_BLOCK_COUNT][HERAIX_BLOCK_SIZE];

void init(void)
{
}

void notified(microkit_channel ch)
{
    if ((ch != CH_ROOT && ch != CH_VFS) ||
        !heraix_rpc_valid_request(rpc, SVC_STORAGE)) {
        if (ch == CH_ROOT || ch == CH_VFS) {
            rpc->status = RPC_BAD_REQUEST;
            microkit_notify(ch);
        }
        return;
    }

    if (rpc->opcode == OP_STORAGE_INFO) {
        if (rpc->arg0 != 0 || rpc->arg1 != 0) {
            rpc->status = RPC_BAD_REQUEST;
        } else {
            rpc->status = RPC_OK;
            rpc->value0 = HERAIX_BLOCK_SIZE;
            rpc->value1 = HERAIX_BLOCK_COUNT;
            rpc->value2 = HERAIX_STORAGE_OWNER_STORAGE_SERVICE;
        }
        microkit_notify(ch);
        return;
    }

    if (rpc->opcode != OP_BLOCK_READ && rpc->opcode != OP_BLOCK_WRITE) {
        rpc->status = RPC_BAD_REQUEST;
        microkit_notify(ch);
        return;
    }

    uint64_t block = rpc->arg0;
    uint64_t length = rpc->arg1;
    uint64_t block_offset = rpc->arg2;
    if (block >= HERAIX_BLOCK_COUNT || length == 0 ||
        block_offset >= HERAIX_BLOCK_SIZE ||
        length > HERAIX_BLOCK_SIZE - block_offset) {
        rpc->status = RPC_INVALID_RANGE;
        microkit_notify(ch);
        return;
    }

    uint8_t *storage = blocks[block];
    if (rpc->opcode == OP_BLOCK_WRITE) {
        for (uint64_t byte = 0; byte < length; ++byte) {
            storage[block_offset + byte] = io_buffer[byte];
        }
    } else {
        for (uint64_t byte = 0; byte < length; ++byte) {
            io_buffer[byte] = storage[block_offset + byte];
        }
    }

    rpc->status = RPC_OK;
    rpc->value0 = length;
    microkit_notify(ch);
}