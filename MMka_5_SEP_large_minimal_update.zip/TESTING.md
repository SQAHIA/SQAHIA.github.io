# Testing

## Commands

```sh
./scripts/mmka build
./scripts/mmka test
./scripts/mmka run
./scripts/mmka clean
```

`build` compiles and links every PD, then invokes the Microkit SDK to build `loader.img` and `report.txt` under `build/x86_64_generic/debug/`. `test` repeats that build, boots `sel4_32.elf` and the generated image in QEMU, saves serial output to `qemu.log`, and checks required markers. A missing marker prints `[FAIL]` and exits nonzero. The harness collects output for up to six seconds and then kills QEMU if it is still running; a live guest alone is not a pass. `run` is the interactive/long-running QEMU command.

## Verified Environment

- Board/config: `x86_64_generic/debug`
- Kernel and composition: repository seL4 source and Microkit SDK 2.3.1
- Emulator: `qemu-system-x86_64`
- QEMU-visible device: PCI PIIX3 ISA bridge `8086:7000`

## Coverage

The automated run compiles/links Root, System, Memory, Resource, Device, Storage, VFS, File, Userland, Process and Security; generates the Microkit image; boots QEMU; then verifies service RPC, memory allocation, PCI discovery/lookup, block info/write/read/range rejection, Storage-backed VFS open/write/seek/read/stat/close, RAMFS CRUD and directory enumeration, File descriptors and stale-handle rejection, ABI version/size/flags rejection, Userland commands, PID/TID lifecycle, user/group/token management, and ACL allow/deny behavior through their service APIs.

The final line is `MMKA SYSTEM TEST: PASS`. This records marker completion during a QEMU boot; it does not claim graceful guest shutdown or physical-hardware validation.
