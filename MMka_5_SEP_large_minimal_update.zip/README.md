# Heraix MMka

MMkaはseL4とMicrokitの上で動くHeraix user-space OS基盤です。seL4を置き換えず、capability、CSpace/VSpace、TCB、IPC、IRQ、隔離をkernelへ委ね、Heraixサービスがsystem policy、resource/storage/file APIを提供します。

## 対象と実装状況

現在の実行・検証ターゲットは `x86_64_generic + QEMU`、Microkit SDKは同梱の2.3.1です。Phase 1のCore、QEMU PCI config I/OによるDevice Managerの最小経路、RAM-backed Storage、Storage上のVFS node、`/tmp` RAMFS、File Service、versioned Public API、テスト用Userland shell、Process/Thread registry、User/Group/Token/ACL policy serviceが実装されています。対応範囲と制約は [ARCHITECTURE.md](ARCHITECTURE.md) と [SERVICES.md](SERVICES.md) を参照してください。

実装範囲の正式な棚卸しとSEPの段階計画は [MMKA_5_SEP_IMPLEMENTATION_PLAN.md](MMKA_5_SEP_IMPLEMENTATION_PLAN.md) に記録しています。これはMMka 5 Coreの検証済みベースラインであり、MMkaの132項目すべてを実装済みとするものではありません。

## ビルド前提

- `x86_64-linux-gnu-gcc` / `x86_64-linux-gnu-ld`
- `qemu-system-x86_64`
- Microkit SDK 2.3.1（既定値: `microkit-source/release/microkit-sdk-2.3.1`）

SDKを別の場所に置く場合は `MICROKIT_SDK=/path/to/microkit-sdk-2.3.1` を指定できます。公式SDKを取得した場合は、配布物のライセンスと署名を確認してから使用してください。スクリプトはSDKまたはQEMUが欠けている場合、曖昧なビルド失敗ではなく不足依存を明示して終了します。

```sh
./scripts/mmka build
./scripts/mmka run
./scripts/mmka test
./scripts/mmka clean
```

`build` は全PDをcompile/linkし、Microkit system imageを生成します。`run` はQEMUを起動してserial出力を接続します。`test` はbuild後にQEMUを起動し、各service/API/filesystem/userland markerを機械判定します。`test`はmarker取得後も動作し続けるQEMUを6秒で終了させる方式です。QEMUの終了とtest成功は別で、test成功には必要markerがすべて必要です。

## 文書

- [ARCHITECTURE.md](ARCHITECTURE.md): service graph、memory/channel配置、対応環境
- [SERVICES.md](SERVICES.md): 各serviceの責務と実装制限
- [ABI.md](ABI.md): versioned RPC、operation、status、公開header
- [TESTING.md](TESTING.md): build/QEMU/test手順と判定内容
- [LICENSES.md](LICENSES.md): FreeBSD由来コードとライセンス

このリポジトリは完成した汎用OSを意味しません。MMIO/IRQ device管理、永続ブロックデバイス、完全なPOSIX/VFS互換性、複数bus、shellの対話端末入力などは未実装です。
