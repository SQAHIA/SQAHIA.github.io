# Third-Party Code

## FreeBSD STAILQ

- Component: intrusive singly-linked tail queue macros used by the RAMFS node registry
- Source: FreeBSD `sys/sys/queue.h`
- Upstream: https://github.com/freebsd/freebsd-src/blob/main/sys/sys/queue.h
- License: BSD-3-Clause
- Local file: `include/compat/freebsd_stailq.h`
- Modification: retained the upstream STAILQ pointer model and insert/remove/traversal behavior; included only the head, entry, init, first/next, empty, insert-tail, remove-head, remove, and foreach macros. FreeBSD debug hooks and unrelated queue variants were omitted. The macros manage RAMFS free/active vnode nodes and enumeration only; no BSD kernel, VM, scheduler, IPC, or device code is included.